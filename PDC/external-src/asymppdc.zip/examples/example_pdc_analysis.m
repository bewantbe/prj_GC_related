
%==========================================================================
% example_pdc_analysis.m
%==========================================================================

%==========================================================================
%            PDC, threshold and confidence interval calculation.
%==========================================================================
c=asymp_pdc(u,A,pf,nFreqs,metric,alpha);

% Power spectra and coherence calculation
c.SS = ss_alg(A, pf, nFreqs);
c.coh = coh_alg(c.SS);

% Statistically significant PDC on frequency scale
pdc_temp = ((abs(c.pdc)-c.th) > 0).*c.pdc + ((abs(c.pdc)-c.th) <= 0)*(-1);
pdc_temp(ind2sub(size(pdc_temp),find(pdc_temp == -1))) = NaN;
c.pdc_th = pdc_temp;

disp('Done. See graphics and results in "c" structured array.')
disp(' ');