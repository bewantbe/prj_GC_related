% Gour�vitch, Bouquin-Jeannes & Faucon. Linear and nonlinear casuality between 
%     signals: methods, examples and neurophysiological applications. 
%     Biol Cybern 95:349-369, 2006.
%         [http://dx.doi.org/10.1007/s00422-006-0098-0]
%
% Example Model 2: Linear bivariate model with bidirectional influence 
%                          with common source

clear; clc
N=20000;
disp('======================================================================');
disp('             Gour�vitch et al. Biol Cybern 95:349-69, 2006.')
disp('     Model 2: Linear Bivariate model with Bidirectional Influence ')
disp('    at different frequencies in each direction, with Common Source')
disp('         x1-->x2    x2-->x1   x1--x2 (Instantaneous causality)');
disp('======================================================================');

randn('state', sum(100*clock))
wi=randn(3,N);
x1=zeros(1,N);
x2=zeros(1,N);
for t=1:3,
   x1(t)=wi(1,t);
   x2(t)=wi(2,t);
end;
for t=4:N,
   x1(t) =  0.95*sqrt(2)*x1(t-1) - 0.9025*x1(t-2) ... 
                                     - 0.9*x2(t-1) + 0.5*wi(1,t) + 0.5*wi(3,t);
   x2(t) = -1.05*x2(t-1) - 0.85*x2(t-2) ...
                                     - 0.8*x1(t-1) + 0.5*wi(2,t) + 0.5*wi(3,t);
end;

nDiscard = 1000; % number of points discarded at beginning of simulation
nPoints  = 500; % number of analyzed samples points

y=[x1' x2'];     % data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%               gPDC estimation and analysis parameters
%==========================================================================

run example_analysis_parameters % Setting default paramaters 

run example_pre_processing      % Detrending and/or standardization
                                % according to flgDetrend and flg

run example_mvar_estimation     % Estimating VAR and testing adequacy of 
                                % VAR model as well as performing GCT and ICT.

%=======Overriding some default parameters for plotting and analysis=======

flgColor = 0; % Standard x and y-axis scales

metric = 'diag';

run example_pdc_analysis        % Estimate PDC and asymptotic statistics

%save gourevitch2006_model2_gPDC

%========================PDCn Matrix Layout Plotting=======================

w_max=fs/2;
chLabels={'X_1';'X_2'}; %Optional channel labels;
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
         'Name', 'Gourevitch et al.(Biol Cybern, 2006)')
   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   [ax,hT]=suplabel(['Model 2: Linear bivariate ' ...
             'model with common source: ' ...
      int2str(nPoints) ' data points.'],'t');
   set(hT,'FontSize',10); % Subtitle font size
   pdc_xplot_title(alpha,metric); %Main title with PDC type and alpha value
end;
                                          
disp('======================================================================');
disp(' ');
disp('==> Note significant Instantaneous Causality in between pair of ')
disp('    time series. The common influencing source is 0.5*wi(3,t) in the')
disp('    model. The p-value (pValue) should be very small, i.e. p<<0.001.')
disp(' ');
disp('======================================================================');
disp('                    End of example gourevitch02.m');
disp('======================================================================');
   
