% Schelter, Winterhalder, Eichler, Peifer,Hellwig, Guschlbauer, L�cking,
% Dahlhaus & Timmer. Testing for directed influences among neural signals 
% using partial directed coherence. J. Neurosci Methods 152:210-9, 2005.
%         [http://dx.doi.org/10.1016/j.jneumeth.2005.09.001]
% 
% Example Eq. (5) Five-dimensional VAR[4]-process 
%
clear; clc
N=40000;
disp('======================================================================');
disp('       Schelter et al. J Neurosci Methods. 152:210-9, 2005.')
disp('               Linear 5-dimensional VAR[4]-process')
disp('       x2==>x1  x3-->x2 x3==>x4 x3-->x5 x4==x2 x5-->x3  x5==x4');
disp('======================================================================');

randn('state', sum(100*clock))
% Variables initialization
ei=randn(5,N);
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x5=zeros(1,N);
for t=1:4,
   x1(t)=randn(1); x2(t)=randn(1); x3(t)=randn(1); x4(t)=randn(1);
   x5(t)=randn(1);
end;

%chLabels = []; % or 
chLabels = {'x_1';'x_2';'x_3';'x_4';'x_5'};

for t=5:N,
   x1(t) = 0.6*x1(t-1) + 0.65*x2(t-2) + ei(1,t);
   x2(t) = 0.5*x2(t-1) - 0.3*x2(t-2) - 0.3*x3(t-4) + 0.6*x4(t-1) + ei(2,t);
   x3(t) = 0.8*x3(t-1) - 0.7*x3(t-2) - 0.1*x5(t-3) + ei(3,t);
   x4(t) = 0.5*x4(t-1) + 0.9*x3(t-2) + 0.4*x5(t-2) + ei(4,t);
   x5(t) = 0.7*x5(t-1) - 0.5*x5(t-2) - 0.2*x3(t-1) + ei(5,t);
end;

nDiscard=100;  % Number of points discarded at beginning of simulation
nPoints=2000;  % Number of analyzed sample points

y=[x1' x2' x3' x4' x5']; % data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:);

[nSegLength,nChannels]=size(u);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================

run example_analysis_parameters % Setting default paramaters 

run example_pre_processing      % Detrending and/or standardization

run example_mvar_estimation     % Estimating VAR and testing adequacy of 
                                % VAR model as well as performing GCT and ICT.

%=======Overriding some default parameters for plotting and analysis=======

flgPrinting=[1 1 1 0 0 0 2]; % overriding default setting

% alpha=0.05;         % Significance level
% gct_signif = 0.05;  % Granger causality test significance level
% igct_signif = 0.05; % Instantaneous GCT significance level
flgColor = 0;
metric = 'diag';

run example_pdc_analysis

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================

w_max=fs/2;

for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
      'Name', 'Schelter et al. J. Neurosci Methods (2005)')
%    [ax,hT]=suplabel(['Linear pentavariate, VAR[4]-process: ' ...
%       int2str(nPoints) ' data points.'],'t');
%    set(hT,'FontSize',12); % Title font size
   pdc_xplot_title(alpha,metric);
   [hxlabel hylabel] = pdc_xplot(c,...
                               flgPrinting,fs,w_max,chLabels,kflgColor);
end;

disp('==> Check the plot with Figs. 1 and 3 (see pages 212 and 215 Schelter')
disp('    et al., 2005) As you may notice, the power spectra of x4, as well ')
disp('    as PDC_24, differ significantly.')
disp('    Our guess is that Schelter et al. may have used slightly different')
disp('    parameters from what they stated in Eq. 5.')
disp('    ')

disp('==> Note that, for linear model with balanced innovation, the maximum')
disp('    of PDC estimates is roughly proportional to the autoregressive ')
disp('    model coefficients. As we are plotting PDC^2, amplitude is proportional')
disp('    to the square of coefficient.')
disp(' ')



disp('======================================================================');
disp('                    This concludes schelter2005.m');
disp('======================================================================');
