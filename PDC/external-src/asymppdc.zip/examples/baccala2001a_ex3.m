% Baccala & Sameshima. Partial directed coherence: a new concept in neural
% structure determination. Biol. Cybern. 84:463-474, 2001.
%                http://dx.doi.org/10.1007/PL00007990
% Example 3 (pag.468)
%                       VAR(3) with loop and feedback

clear; clc
N=10000;
disp('======================================================================');
disp('               Linear five-dimensional VAR[3] Model')
disp(' Baccala & Sameshima. Biol.Cybern.84:463-74, 2001. Example 3 (pag.468)')
disp('             x1-->x2  x1-->x3 x1-->x4 x4-->x5 x5-->x4');
disp('======================================================================');

randn('state', sum(100*clock))
ei=randn(5,N);
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x5=zeros(1,N);
% Variables initialization
for t=1:4,
   x1(t)=randn(1); x2(t)=randn(1); x3(t)=randn(1); x4(t)=randn(1);
   x5(t)=randn(1);
end;

chLabels = []; % or 
%chLabels = {'x_1';'x_2';'x_3';'x_4';'x_5'};


for t=5:N,
   x1(t) = 0.95*sqrt(2)*x1(t-1) - 0.9025*x1(t-2) + ei(1,t);
   x2(t) = 0.5*x1(t-2) + ei(2,t);
   x3(t) = -0.4*x1(t-3) + ei(3,t);
   x4(t) = -0.5*x1(t-2) + 0.25*sqrt(2)*x4(t-1) + 0.25*sqrt(2)*x5(t-1) + ei(4,t);
   x5(t) = -0.25*sqrt(2)*x4(t-1) + 0.25*sqrt(2)*x5(t-1) + ei(5,t);
end;

nDiscard=1000; % number of points discarded at beginning of series
nPoints=200;   % number of analyzed samples points

y=[x1' x2' x3' x4' x5']; % data must be organized column-wise

u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================


run example_analysis_parameters % Setting default paramaters 

run example_pre_processing      % Detrending and/or standardization

run example_mvar_estimation     % Estimating VAR and testing adequacy of 
                                % VAR model as well as performing GCT and ICT.

%=======Overriding some default parameters for plotting and analysis=======

flgPrinting = [1 1 1 0 0 0 3]; % overriding default setting
% alpha=0.05;         % Significance level
% gct_signif = 0.05;  % Granger causality test significance level
% igct_signif = 0.05; % Instantaneous GCT significance level
% flgColor = 0;
metric = 'euc';

run example_pdc_analysis        % Estimate PDC and asymptotic statistics

%save baccala2001a_ex3_PDC

flgColor = 0;
%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
w_max=fs/2;

strTitle1 = ['3-dimensional linear VAR[3] Model: '];
strTitle2 = ['[N=' int2str(nSegLength) 'pts; IP=' int2str(c.p) '; ' ...
   datestr(now) ']'];
strTitle =[strTitle1 strTitle2];

for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
         'Name', 'Baccal� & Sameshima (2001) Example 3')
   [hxlabel hylabel] = pdc_xplot(c,...
                                 flgPrinting,fs,w_max,chLabels,kflgColor);
   pdc_xplot_title(alpha,metric);
   [ax,hT]=suplabel( strTitle, 't' );
   set(hT,'FontSize',8) 
end;

disp('')
disp('==> Check & compare Fig. 2b, page 468, Baccala & Sameshima (2001).')
disp(' ')
disp('==> Note that in the original article the amplitude PDC has been plotted.')
disp('    Here we preferred to graph squared-PDC.')
disp(' ')
disp('======================================================================');
disp('      This completes the Example 3 (Baccal� & Sameshima, 2001)');
disp('======================================================================');
