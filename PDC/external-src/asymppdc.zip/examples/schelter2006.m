%==========================================================================
%      Schelter, Winterhalder, Hellwig, Guschlbauer, L�cking, Timmer
%       Direct or indirect? Graphical models for neural oscillators
%               J Physiology - Paris 99:37-46, 2006.
%         http://dx.doi.org/10.1016/j.jphysparis.2005.06.006
%
%      Example 5-dimensional VAR[4]
%==========================================================================

clc; clear; format compact; format short

flgRepeat = 1; % You may want to repeat simulation using the same data set 
               % with different analysis parameters. If this is the case, 
               % run schelter2006.m with flgRepeat = 0, then set it to 1,
               % then you will be able to play with the same dataset using
               % different analysis and plotting parameters. 
               % When flgRepeat == 0, the state number is saved in
               % schelter2006_state.mat file, so that randn can be
               % initialized with the same state number in subsequent
               % simulations.
N=60000;
disp('======================================================================');
disp('         Schelter et al. J Physiology - Paris 99:37-46, 2006.')
disp('                Linear penta-variate VAR[4]-process')
disp('       x1-->x2  x1-->x4 x2-->x4 x4==>x5 x5-->x1  x5-->x2 x5-->x3 ');
disp('======================================================================');

if flgRepeat,
   if exist('schelter2006_state.mat', 'file') == 2,
      load schelter2006_state.mat % Retrieving saved state number.
      if ~exist('aState','var'),
         disp('State number does not exist. State number initialized.')
         aState = sum(100*clock);
      else
         disp('Using saved state number to repeat simulation with same dataset.');
      end;
   else
      disp('File schelter2006_state.mat not found. Using newly state number.')
      aState = sum(100*clock);
      save schelter2006_state.mat aState
   end
else
   aState = sum(100*clock); % Starting a new state number.
   
end;

randn('state',aState)

ei=randn(5,N);
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x5=zeros(1,N);
% Variables initialization
for t=1:6,
   x1(t)=randn(1); x2(t)=randn(1); x3(t)=randn(1); x4(t)=randn(1);
   x5(t)=randn(1);
end;

%chLabels = []; % or 
chLabels = {'x_1';'x_2';'x_3';'x_4';'x_5'};

for t=7:N,
   x1(t) = 0.4*x1(t-1) - 0.5*x1(t-2) + 0.4*x5(t-1) + ei(1,t);
   x2(t) = 0.4*x2(t-1) - 0.3*x1(t-4) + 0.4*x5(t-2) + ei(2,t);
   x3(t) = 0.5*x3(t-1) - 0.7*x3(t-2) - 0.3*x5(t-3) + ei(3,t);
   x4(t) = 0.8*x4(t-3) + 0.4*x1(t-2) + 0.3*x2(t-2) + ei(4,t);
   x5(t) = 0.7*x5(t-1) - 0.5*x5(t-2) - 0.4*x4(t-1) + ei(5,t);
end;

nDiscard=1000; % number of points discarded at beginning of series
nPoints=2000;   % number of analyzed samples points

y=[x1' x2' x3' x4' x5']; % data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:);
[nSegLength,nChannels]=size(u);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================

run example_analysis_parameters % Setting default paramaters 

run example_pre_processing      % Detrending and/or standardization

run example_mvar_estimation     % Estimating VAR and testing adequacy of 
                                % VAR model as well as performing GCT and ICT.

%=======Overriding some default parameters for plotting and analysis=======

flgPrinting = [1 1 1 1 1 0 2];
% alpha=0.05;         % Significance level
% gct_signif = 0.05;  % Granger causality test significance level
% igct_signif = 0.05; % Instantaneous GCT significance level

metric = 'euc';
alpha=0.01;         % Significance level
gct_signif = 0.01;  % Granger causality test significance level
igct_signif = 0.01; % Instantaneous GCT significance level
flgColor = 0;

run example_pdc_analysis

%save schelter2006_PDC

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================

w_max=fs/2;
alphastr = int2str(100*alpha);
   
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
      'Name', 'Schelter et al. J Physiology - Paris 99:37-46, 2006.')

   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   [ax,hT]=suplabel(['Linear pentavariate Model II: ' ...
      int2str(nPoints) ' data points.'],'t');
   set(hT,'FontSize',12); % Title font size
   pdc_xplot_title(alpha,metric);
end;

if ~flgRepeat,
   save schelter2006_state.mat aState
end;

disp('==> Compare this plot with Fig.3 in Schelter et al. (2006),')
disp('    depicting PDC''s amplitude plots, while this example plots squared')
disp('    PDC.')
disp(' ')
disp('==> Note that, for linear model, the mean amplitude of PDC estimates')
disp('    is roughly proportional to relative coefficient values of ')
disp('    the autoregressive model.')
disp(' ')
disp('======================================================================');
disp('                    End of example schelter2006.m');
disp('======================================================================');
