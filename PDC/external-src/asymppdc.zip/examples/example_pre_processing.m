
%==========================================================================
%                         example_pre_processing.m
%==========================================================================

disp('Running simple data pre-processing routines.')

%==========================================================================
%                    Detrend and normalization options
%==========================================================================
if flgDetrend,
   for i=1:nChannels, u(:,i)=detrend(u(:,i)); end;
   disp('Time series were detrended.');
end;

[nChannels,nSegLength]=size(u);
if nChannels > nSegLength, u=u.'; 
   [nChannels,nSegLength]=size(u);
end;

if flgStandardize,
   for i=1:nChannels, u(:,i)=u(:,i)/std(u(:,i)); end;
   disp('Time series were standardized.');
end;

