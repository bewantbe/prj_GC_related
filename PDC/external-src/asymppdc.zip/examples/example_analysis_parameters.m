
% Common routine segment for examples
disp('Setting up default analysis parameters.')

[nSegLength,nChannels]=size(u);

flgDetrend=1;
flgStandardize=0;

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================

fs=1; maxIP=30; 
criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
nFreqs=128;
alpha=0.01;     % Significance level
gct_signif = 0.01; % Granger causality test significance level
igct_signif = 0.01; % Instantaneous GCT significance level
MVARadequacy_signif = 0.05; % VAR model estimation adequacy significance
metric='diag'; % euc  = original PDC;
               % diag = generalized PDC or gPDC;
               % info = informational PDC or iPDC.

%==========================================================================
%                    Plotting options
%==========================================================================
flgColor = [0 1]; % Plotting option for automatic scaling for small PDC
                  % values.
                  % if flgColor = 0, y-axis scale = [0 1]
                  % elseif flgColor = 1, pdc_xplot routine rescale 
                  % the y-axis automatically according to following rules:
                  %   If .001<=PDC(f) < .01 background-color = light-blue,
                  %                          so that y-axis scale = [0 .1]
                  %   elseif PDC(f) < .001 background-color = light-purple
                  %                          and y-axis = [0 .01];
                  % for flgColor=[0 1], both lay-outs are plotted.

%           [1 2 3 4 5 6 7]
flgPrinting=[1 1 1 1 1 0 1];
%            | | | | | | 7 Power Spectra (0: w/o SS; 1: Linear; 2: Log-scale)
%            | | | | | 6 Coherence
%            | | | | 5 Plot lower confidence limit
%            | | | 4 Plot upper confidence limit
%            | | 3 Significant PDC in red line
%            | 2 Patnaik threshold level in black dashed-line
%            1 PDC in green line

axis_scale = [0 0.50 -0.02 1.05];
w=fs*(0:(nFreqs-1))/2/nFreqs;

