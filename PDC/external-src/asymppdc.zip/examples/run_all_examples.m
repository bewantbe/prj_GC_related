%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Sunspot and melanoma data 1936 - 1972
%     sunspot --> melanoma 
andrews_herzberg
shg
pause(2)

%==========================================================================
% Baccala & Sameshima. Partial directed coherence: a new concept in neural
% structure determination. Biol. Cybern. 84:463-474, 2001.
% 
% Example VAR(5) with loop and feedback 4<=>5 Example 3
baccala2001a_ex3
shg
pause(2)

% Example VAR(5) with loop and feedback  (4<=>5) Example 4
baccala2001a_ex4
shg
pause(2)

% Example VAR(5) with loop and feedback
baccala2001a_ex5
shg
pause(2)

%==========================================================================
% Baccal�, L. A. & Sameshima, K. (2001b) Overcoming the limitations of
% correlation analysis for many simultaneously processed neural structures.
% Progress in Brain Research, 130, pp. 33�47. 
%
% Example VAR(5) + independent VAR(2)

baccala2001b
shg
pause(2)

%==========================================================================
% Gour�vitch, Bouquin-Jeannes, Faucon
% Linear and nonlinear casuality between signals: methods, examples and
% neurophysiological applications. Biol Cybern 95:349-369, 2006.
%==========================================================================

% Example Model 2: Linear bivariate model with bidirectional influence 
% with common source
gourevitch2006_model2
shg
pause(2)

%==========================================================================
% Guo, Wu, Ding & Feng. Uncovering interactions in frequency domains. PLoS
% Computational Biology, 4(5):1-10, February 8, 2008. 
%==========================================================================
% Page 2 Toy Model Example VAR(5) + VAR(2) with loop and feedback
guo2008_linear
shg
pause(2)

%==========================================================================
% Schelter, Winterhalder, Eichler, Peifer,Hellwig, Guschlbauer, L�cking,
% Dahlhaus, Timmer. Testing for directed influences among neural 
% signals using partial directed coherence. Journal of Neuroscience Methods
% 152:210-218, 2005.
%==========================================================================
% Example VAR(4) 
schelter2005
shg
pause(2)

%==========================================================================
% J Physiology - Paris 99:37-46, 2006.
% Direct or indirect? Graphical models for neural oscillators
% Bj�rn Schelter, Matthias Winterhalder, Bernhard Hellwig, 
% Brigitte Guschlbauer, Carl Hermann L�cking, Jens Timmer
%==========================================================================
% 
% Example VAR(4) 
schelter2006
shg
pause(2)

%==========================================================================
% Schelter, Timmer, Eichler. Assessing the strength of directed influences
% among neural signals using renormalized PDC. J Neurosci Methods (2009 in
% press). 
%==========================================================================
% 3.1 Vector autoregressive process I (pag. )
schelter2009_vap1
shg
pause(2)

% 3.1 Vector autoregressive process II (pag. )
schelter2009_vap2
shg
pause(2)

%==========================================================================
% Winterhalder et al.Comparison of linear signal processing techniques to
% infer directed interactions in multivariate neural systems. 
% Signal Processing 85:2137�2160, 2005.
%==========================================================================
% Variant of Random Independent Process with 7 variables')
% sigma1=500; sigma2=1; sigma3=500; sigma4=1; sigma5=1; sigma6=1; sigma7=1;
%
% Example: Seven random independent variables 

winterhalder2005_variant

disp('====================================================================');
disp('================ALL_EXAMPLES SUCCESSFULLY FINISHED =================')
disp('====================================================================');
