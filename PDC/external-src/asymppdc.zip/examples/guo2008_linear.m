% Guo, Wu, Ding & Feng. Uncovering interactions in frequency domains.
%         PLoS Computational Biology, 4(5):1-10, February 8, 2008.
%           [http://dx.plos.org/10.1371/journal.pcbi.1000087] 
% 
% Page 2 Toy Model Example VAR(5) with common exogenous input

clc; format compact
N=60000;
disp('======================================================================');
disp('                   Five dimensional linear VAR[2] Model')
disp('                    with large common exogenous input')
disp('                      Guo et al. February 8, 2008.')
disp('                 x1==>x2  x1-->x3 x1==>x4 x4-->x5 x5-->x4 ');
disp('             Instantaneous causality in between all variables.');
disp('======================================================================');
if ~exist('flgManual','var')
   flgManual = 0
end;

if flgManual
   if exist('randn_manual_state.mat','file'),
      load randn_manual_state
      randn('state', s);
      disp(['Using state saved in "randn_manual_state.mat" to reproduce figure in the manual.']);
   else
      disp(['Did not find "randn_manual_state.mat" file.' ...
         'Assigned "sum(100*clock)" initial state.']);
      randn('state', sum(100*clock))
   end;
else
   randn('state', sum(100*clock))
   disp('Assigned "sum(100*clock)" initial state.2')
end;
% Variables initialization
ei=randn(7,N);
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x5=zeros(1,N);

a1=rand; a2=rand; a3=rand; a4=rand; a5=rand;
b1=2; b2=2; b3=2; b4=2; b5=2;
c1=5; c2=5; c3=5; c4=5; c5=5;
% The model with all above parameters set to zero corresponds to Example 4 
% of Baccala & Sameshima (2001). See example baccala2001a_ex4.m
% a1=0; a2=0; a3=0; a4=0; a5=0;
% b1=0; b2=0; b3=0; b4=0; b5=0;
% c1=0; c2=0; c3=0; c4=0; c5=0;

disp(sprintf('a1=%f; a2=%f; a3=%f; a4=%f; a5=%f;',a1,a2,a3,a4,a5))
disp('b1 = b2 = b3 = b4 = b5 = 2;')
disp('c1 = c2 = c3 = c4 = c5 = 5;')
disp('======================================================================');

for t=1:4,
   x1(t)=randn(1); x2(t)=randn(1); x3(t)=randn(1); x4(t)=randn(1);
   x5(t)=randn(1); 
end;

chLabels = {'x_1';'x_2';'x_3';'x_4';'x_5'}; %or %chLabels = []; 

for t=5:N,
   x1(t) = 0.95*sqrt(2)*x1(t-1) - 0.9025*x1(t-2) + ei(1,t) + ...
                                 a1*ei(6,t) + b1*ei(7,t-1) + c1*ei(7,t-2);
   x2(t) = 0.5*x1(t-2) + ei(2,t) + ...
                                 a2*ei(6,t) + b2*ei(7,t-1) + c2*ei(7,t-2);
   x3(t) =-0.4*x1(t-3) + ei(3,t) + ...
                                 a3*ei(6,t) + b3*ei(7,t-1) + c3*ei(7,t-2);
   x4(t) =-0.5*x1(t-2) + 0.25*sqrt(2)*x4(t-1) + 0.25*sqrt(2)*x5(t-1) ...
                     + ei(4,t) + a4*ei(6,t) + b4*ei(7,t-1) + c4*ei(7,t-2);
   x5(t) =-0.25*sqrt(2)*x4(t-1) + 0.25*sqrt(2)*x5(t-1) ...
                     + ei(5,t) + a5*ei(6,t) + b5*ei(7,t-1) + c5*ei(7,t-2);
end;


nDiscard=5000;  % number of points discarded at beginning of series
nPoints=2000;   % number of analyzed samples points

y=[x1' x2' x3' x4' x5']; % data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:);

[nSegLength,nChannels]=size(u);

%==========================================================================
%             original PDC estimation and analysis parameters
%==========================================================================

run example_analysis_parameters % Setting default paramaters 

run example_pre_processing      % Detrending and/or standardization

run example_mvar_estimation     % Estimating VAR and testing adequacy of 
                                % VAR model as well as performing GCT and ICT.

%=======Overriding some default parameters for plotting and analysis=======

metric = 'euc';
flgColor = 0;

run example_pdc_analysis        % Estimate PDC and asymptotic statistics

%========================PDCn Matrix Layout Plotting=======================
w_max=fs/2;
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
      'Name', 'Guo et al.(2008) Linear model with large common exogenous inputs')
   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   pdc_xplot_title(alpha,metric);
end;

%==========================================================================
%       gPDC analysis of Guo et al (2008) Common exogenous noise model
%==========================================================================

%=======Overriding some default parameters for plotting and analysis=======
flgPrinting = [1 0 1 0 0 0 1]; % overriding default setting
metric = 'diag';
flgColor = [0];

run example_pdc_analysis

%========================gPDC Matrix Layout Plotting=======================

w_max=fs/2;
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
      'Name', 'Guo et al.(2008) Linear model with large common exogenous inputs')
   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   pdc_xplot_title(alpha,metric);
end;

%==========================================================================
%                     iPDC analysis of the same process
%==========================================================================

%====Overriding default some parameters value for plotting andanalysis=====

flgPrinting = [1 0 1 0 0 0 1]; % overriding default setting

metric = 'info';
flgColor = [0 1];

run example_pdc_analysis


%========================iPDC Matrix Layout Plotting=======================
w_max=fs/2;
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
      'Name', 'Guo et al.(2008) Linear model with large common exogenous inputs')
   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   pdc_xplot_title(alpha,metric);
end;

disp('==> Guo et al. (2008)''s five-dimensional VAR[3] process with large')
disp('    common exogenous inputs, a modified version of a example ')
disp('    from Baccal� & Sameshima (2001). The exogenous inputs')
disp('    introduce large common variance that overpower the magnitude of')
disp('    directed interactions. As you may have noticed, there are')
disp('    significant instantaneous Granger causality between all pair of')
disp('    variables.')
disp('    Due to large common exogenous white noise probably one may see ')
disp('    false-positive and false-negative connectivity in some ')
disp('    simulations, which will depend on your choice of alpha.')
disp('    ')
disp('==> The PDC and gPDC figures do not resemble PDC plot in Fig.1')
disp('    in Guo et al. (2008). Our best guess is that Guo & colleagues')
disp('    used a incorrect PDC estimator. Actually you may notice')
disp('    that PDC and gPDC estimates are very similar to PGC ')
disp('    in Guo et al.')
disp('==> In all three PDC formulations, the significant PDC frequecy ') 
disp('    range is similar. iPDC gives a measure of size effect, which is')
disp('    very small in this case. Even so iPDC is significant in the same')
disp('    frequency range as PDC and gPDC.')
disp('==> In conclusion: the statement by Guo and collaborators that PDC can')
disp('    not uncover the connectivity pattern in large common noise does')
disp('    hold. For nonlinear systems, in some cases PDC and other linear')
disp('    methods can uncover correct connectivity pattern, but in other')
disp('    models PDC and GCT simply fail.') 

disp(' ')
disp('======================================================================');
disp('             This completes Guo et al. (2008) example.');
disp('======================================================================');
