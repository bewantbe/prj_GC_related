% Winterhalder et al.Comparison of linear signal processing techniques to
% infer directed interactions in multivariate neural systems. 
% Signal Processing 85:2137�2160, 2005.
%    [http://dx.doi.org/10.1016/j.sigpro.2005.07.011]
%
% Example: Seven random independent variables 

clear; clc

disp('======================================================================');
disp('       Winterhalder et al. Signal Processing. 85:2137�60, 2005')
disp('        Variant of Random Independent Process with 7 variables')
disp(' [sigma1=500|sigma2=1|sigma3=500|sigma4=1|sigma5=1|sigma6=1|sigma7=1]');
disp('======================================================================');

randn('state', sum(100*clock))
ei=randn(10,20000);

sigma1=500; sigma2=1; sigma3=500; sigma4=1; sigma5=1; sigma6=1; sigma7=1;

x1=sigma1*ei(1,:); x2=sigma2*ei(4,:); x3=sigma3*ei(6,:); x4=sigma4*ei(7,:);
x5=sigma5*ei(5,:); x6=sigma6*ei(2,:); x7=sigma7*ei(8,:);

%chLabels = []; % or 
chLabels = {'x_1';'x_2';'x_3';'x_4';'x_5';'x_6';'x_7'};

y=[x1' x2' x3' x4' x5' x6' x7'];
nDiscard=1000; % number of points discarded at beginning of series
nPoints=5000;   % number of analyzed samples points
u=y(nDiscard+1:nDiscard+nPoints,:);

clear y x1 x2 x3 x4 x5 x6 x7 ei

[nSegLength,nChannels]=size(u);

%==========================================================================
%                     PDC estimation and analysis parameters
%==========================================================================

run example_analysis_parameters % Setting default paramaters 

run example_pre_processing      % Detrending and/or standardization

run example_mvar_estimation     % Estimating VAR and testing adequacy of 
                                % VAR model as well as performing GCT and 
                                % ICT.

%=======Overriding some default parameters for plotting and analysis=======

flgPrinting=[1 1 1 0 0 0 1]; % overriding default setting

% alpha=0.05;         % Significance level
% gct_signif = 0.05;  % Granger causality test significance level
% igct_signif = 0.05; % Instantaneous GCT significance level


flgColor = [0];
metric = 'euc';

run example_pdc_analysis

%save winterhalder2005_variant_PDC

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
w_max=fs/2;
strTitle= ['PDC (' '{\alpha = ' int2str(100*alpha) '%}' ')'];
switch metric
   case 'euc'
      %nop
   case 'diag'
      strTitle= ['g' strTitle];
   case 'info'
      strTitle= ['i' strTitle];
   otherwise
      error('Unknown metric.')
end;
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
      'Name', 'Winterhalder et al. Signal Processing 85:2137�60, 2005')
   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   [ax,hT]=suplabel([strTitle ' Independent Gaussian noises: \sigma_1=\sigma_3=500;' ...
                  ' \sigma_2 = \sigma_4 = \sigma_5 = 1'],'t');
               
   set(hT,'FontSize',10); % Title font size
   

end;

%==========================================================================
%                     gPDC estimation and analysis parameters
%==========================================================================

flgColor = [0 1];
metric = 'diag';

run example_pdc_analysis

%save winterhalder2005_variant_gPDC

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
w_max=fs/2;
strTitle= ['PDC (' '{\alpha = ' int2str(100*alpha) '%}' ')'];
switch metric
   case 'euc'
      %nop
   case 'diag'
      strTitle= ['g' strTitle];
   case 'info'
      strTitle= ['i' strTitle];
   otherwise
      error('Unknown metric.')
end;
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
      'Name', 'Winterhalder et al. Signal Processing 85:2137�60, 2005')
   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   [ax,hT]=suplabel([strTitle ' Independent Gaussian noises: \sigma_1=\sigma_3=500;' ...
                  ' \sigma_2 = \sigma_4 = \sigma_5 = 1'],'t');
               
   set(hT,'FontSize',10); % Title font size
   
end;

disp('======================================================================');
disp(' ');
disp('==> As 42 combinations of PDC/GC are tested, chance is that you')
disp('    will see significant PDC (red lines) in some plottings. The ') 
disp('    significant PDC probability depends on significance level you ') 
disp('    choose for PDC testing.')
disp('==> The similar argument applies to "instantaneous Granger causality"' )
disp('    outcomes, and combination of 21 pairs of variables are considered') 
disp('    as IGC is a symmetric relation.')
disp(' ');
disp('======================================================================');
disp('                  End of winterhalder2005_variant.m');
disp('======================================================================');
