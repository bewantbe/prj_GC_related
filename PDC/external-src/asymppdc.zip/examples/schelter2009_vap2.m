% Schelter, Timmer, Eichler. 
% Assessing the strength of directed influences among neural signals using
% renormalized PDC. J Neurosci Methods, 179:121-130, 2009.
%   [http://dx.doi.org/10.1016/j.jneumeth.2009.01.006]
% 
% 3.1 Vector autoregressive process II (Eqs. 16-20, page 124)

clear; clc
N=10000;
disp('======================================================================');
disp('                    Five-dimensional VAR[2] process')
disp('              Schelter et al. J Neurosci Methods (2009).')
disp('                  x1-->x2  x1-->x5 x4-->x3 x5-->x3');
disp('======================================================================');

randn('state', sum(100*clock))
ei=randn(5,N);
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x5=zeros(1,N);
% Variables initialization
for t=1:4,
   x1(t)=randn(1); x2(t)=randn(1); x3(t)=randn(1); x4(t)=randn(1);
   x5(t)=randn(1);
end;

for t=5:N,
   x1(t) = 1.9*x1(t-1) - 0.999*x1(t-2) + ei(1,t);
   x2(t) = 0.9*x2(t-2) - 0.2*x1(t-1) + ei(2,t);
   x3(t) = -.3*x3(t-1) + 0.4*x4(t-1) - 0.3*x5(t-2) + ei(3,t);
   x4(t) = 1.3*x4(t-1) - 0.7*x4(t-2) + ei(4,t);
   x5(t) = 0.7*x5(t-2) + 0.3*x1(t-1) + ei(5,t);
end;

nDiscard=1000; % number of points discarded at beginning of series
nPoints=3000;   % number of analyzed samples points

%chLabels = []; % or 
chLabels = {'x_1';'x_2';'x_3';'x_4';'x_5'};

y=[x1' x2' x3' x4' x5']; % data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
run example_analysis_parameters % Setting default paramaters 

run example_pre_processing      % Detrending and/or standardization

run example_mvar_estimation     % Estimating VAR and testing adequacy of 
                                % VAR model as well as performing GCT and ICT.

%=======Overriding some default parameters for plotting and analysis=======
flgPrinting = [1 1 1 1 1 0 0]; 
alpha=0.05;     % Significance level
gct_signif = 0.05; % Granger causality test significance level
igct_signif = 0.05; % Instantaneous GCT significance level
metric = 'info';

run example_pdc_analysis

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================

w_max=fs/2;
alphastr = int2str(100*alpha);
   
for kflgColor = flgColor,
   h=figure;
   set(h,'NumberTitle','off','MenuBar','none', ...
         'Name', 'Schelter et al. (2009)')
   [hxlabel hylabel] = pdc_xplot(c,...
      flgPrinting,fs,w_max,chLabels,kflgColor);
   [ax,hT]=suplabel(['Schelter et al. (2009) linear model: ' ...
      int2str(nPoints) ' data points.'],'t');
   set(hT,'FontSize',10); % Title font size
   pdc_xplot_title(alpha,metric);
end;

disp('')
disp('==> Note that for linear model the mean amplitude of PDC estimates is')
disp('    roughly proportional to  relative coefficient values of ')
disp('    the autoregressive model.')
disp('======================================================================');
disp('                    End of example schelter2009_vap2.m');
disp('======================================================================');
