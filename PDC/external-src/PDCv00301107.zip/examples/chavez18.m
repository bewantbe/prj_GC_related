% Equation (18): Linear Bivariate model (p.118)
%
%   ( Ch�vez, Martinerie, Van Quyen. Statistical assessment 
%     of nonlinear causality: Application to epileptic EEG signals. 
%     J Neurosci Methods. 124:113-128, 2003. )
%
%                                   (See also Diks and DeGoede, 2001).

clear all; clc
N=10000;
disp('======================================================================');
disp('              Equation 18 (p.118): Linear Bivariate Model');
disp('               Chavez et al. J. Neurosci. Methods (2003)')
disp('                              Y --> X');
disp('======================================================================');
randn('state', sum(100*clock));
wi=randn(2,N);
x=zeros(1,N);
y=zeros(1,N);
for t=1:2,
   y(t)=wi(1,t);
   x(t)=wi(2,t);
end;
sigma=wi(1,:);
v=wi(2,:);
for t=3:N,
   y(t)=0.6*y(t-1)+ sigma(t);
   x(t)=0.6*x(t-1)+0.5*y(t-1)+v(t);
end;

yy=[y' x']; % data must be organized column-wise

nDiscard=1000; % number of points discarded at beginning of simulated series
nPoints=5000;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure; chLabels={'y';'x'}; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel('Chavez et al (Eq-18)','t');
set(hT,'FontSize',14); % Title font size

%==========================================================================
%           If you wish to play with Cornish-Fisher transformation, 
%                    uncomment all the following lines:
%==========================================================================

% disp('======================================================================');
% disp('              Press any key or wait 10 sec to continue ...');
% disp('======================================================================');
% pause(10);
% disp('                 Analysis of C-F transformed data')
% disp('                 ================================');
% df=1;
% u=cornish_fisher(u,df);
% [SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
%                                anapdcn(u,fs,maxIP,criterion,alg,aSignif);
% figure;
% [hxlabel hylabel] = pdc_xplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
%                                               flgPrinting,fs,w_max,chLabels);
% [ax,hT]=suplabel(['Chavez et al (Eq-18): ' ...
%                               'Cornish-Fisher transformation effect'],'t')
% set(hT,'FontSize',[14]); % Title font size

disp('======================================================================');
disp('                      End of example chavez18.m                       ');
disp('======================================================================');
