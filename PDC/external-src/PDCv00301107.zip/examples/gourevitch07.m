% Biol Cybern 2006
% Linear and nonlinear casuality between signals: methods, examples and
% neurophysiological applications
% Gour�vitch, Bouquin-Jeannes, Faucon
% Example Model 7: nonlinear trivariate model
clear all; clc
N=20000;
randn('state', sum(100*clock))
wi=randn(3,N);

disp('======================================================================');
disp('                     NonLinear Trivariate Model')
disp('             Gour�vitch et al. Biol Cybern 95:349-369, 2006')
disp('                    x1-->x2    x1-->x3      x2-->x3');
disp('======================================================================');

x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);

for t=1:3,
   x1(t)=wi(1,t);
   x2(t)=wi(2,t);
   x3(t)=wi(3,t);
end;
for t=2:N,
   x1(t)=3.4*x1(t-1)*(1-x1(t-1)^2)*exp(-x1(t-1)^2)+0.4*wi(1,t);
   x2(t)=3.4*x2(t-1)*(1-x2(t-1)^2)*exp(-x2(t-1)^2)+0.5*x1(t-1)*x2(t-1)+0.4*wi(2,t);
   x3(t)=3.4*x3(t-1)*(1-x3(t-1)^2)*exp(-x3(t-1)^2)+0.3*x2(t-1)+0.5*x1(t-1)^2+0.4*wi(3,t);
end;

y=[x1' x2' x3']; % data must be organized column-wise
nDiscard = 1000; % number of points discarded at beginning of simulation
nPoints  = 10000; % number of analyzed samples points
aSignif  = 0.01; % Significance level for PDC testing
u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.01; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure;; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max);
[ax,hT]=suplabel(['Gourevitch et al. Biol Cybern Model 7:' ...
                  ' nonlinear bivariate model'],'t');
set(hT,'FontSize',14);
disp('======================================================================');
disp('==> Note that PDC can uncover x2 --> x3, because x2 ')
disp('    is a linear component influencing x3.')

disp('======================================================================');
disp('           Press any key or wait 10 sec to continue ...');
disp('======================================================================');
pause(10);
disp('                  C-F Transformed Data Analysis')
disp('                 ================================');

df=1;
u=cornish_fisher(u,df);
%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max);
[ax,hT]=suplabel(['Gourevitch et al. Biol Cybern Model 7:' ...
                  ' Cornish-Fisher transformation of data.'],'t');
set(hT,'FontSize',14);

disp('======================================================================');
disp('==> PDC outcome will vary for each simulation because the weights of ')
disp('    x1-->x2, x1-->x3 and x2-->x3 influences are relatively small. ')
disp('    You''ll also notice eventual significant PDC (red lines) on other')
disp('    connections, but the absolute amplitude is very small, on the order')
disp('    of 10**(-5).')
disp('==> The previously significant x2-->x3 might not be present most of the')
disp('    time after C-F transformation. Even significant, you''ll notice ')
disp('    its PDC amplitude decreases significantly compared to the original')
disp('    data analysis.')
disp('==> Play several times to check for outcome variations. Try diferent ')
disp('    number of samples (nPoints) and/or PDC test significant level.')

disp('======================================================================');
disp('                      End of example gourevitch06.m');
disp('======================================================================');
