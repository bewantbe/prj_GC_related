% Takahashi, Baccal�, Sameshima
% Partial Directed Coherence Asymptotics for VAR Processes of Infinite Order
% Special Issue of International Journal of Bioelectromagnetism 
% NEUROMATH Workshop Roma, 4-5 December 2007
%
% Example: An invertible VMA process with an infinite order VAR process 
% representation was simulated

clear all; clc
N=30000;
disp('======================================================================');
disp('                        VMA Bivariate Model');
disp('          Takahashi et al. International J. Biolectromagnetism')
disp('                               Y --> X');
disp('======================================================================');
randn('state', sum(100*clock));
w1=randn(1,30000);
w2=randn(1,30000);
x1=zeros(1,N);
x2=zeros(1,N);

for k=1:2,
   x1(k)=w1(k);
   x2(k)=w2(k);
end;
% VMA model 
for k=3:30000,
   x1(k) = w1(k) + 0.7*w1(k-1) + 0.9*w2(k-1);
   x2(k) = w2(k) + 0.0*w1(k-1) + 0.4*w2(k-1);
end;
clear w1 w2
yy=[x1' x2']; % data must be organized column-wise
chLabels={'X1';'X2'};
nDiscard=1000; % number of points discarded at beginning of simulated series
nPoints=20;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
maxIP=100;

%============================PDCn calculation==============================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%========================PDCn Matrix Layout Plotting=======================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Takahashi et al. (2007): VMA 20 time points, IP=' ...
                   int2str(IP) '.'],'t');
set(hT,'FontSize',14); % Title font size
disp('======================================================================');


nPoints=200;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nPoints,:);
figure;
%============================PDCn calculation==============================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%========================PDCn Matrix Layout Plotting=======================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Takahashi et al. (2007): VMA 200 time points, IP=' ...
                   int2str(IP) '.'],'t');
set(hT,'FontSize',14); % Title font size

disp('======================================================================');

nPoints=2000;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nPoints,:);
%============================PDCn calculation==============================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%========================PDCn Matrix Layout Plotting=======================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Takahashi et al.(2007): VMA 2000 time points, IP=' ...
                   int2str(IP) '.'],'t');
set(hT,'FontSize',14); % Title font size

disp('======================================================================');

nPoints=20000;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nPoints,:);
%============================PDCn calculation==============================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%========================PDCn Matrix Layout Plotting=======================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Takahashi et al.(2007): VMA 20000 time points, IP=' ...
                   int2str(IP) '.'],'t');
set(hT,'FontSize',14); % Title font size

disp('======================================================================');

nPoints=20000;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nPoints,:);
%============================PDCn calculation==============================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%========================PDCn Matrix Layout Plotting=======================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Takahashi et al.(2007): VMA 20000 time points, fixed IP=' ...
                   int2str(IP) '.'],'t');
set(hT,'FontSize',14); % Title font size

disp('======================================================================');
disp('                      End of takahashi01.m VMA model');
disp('======================================================================');
pause(5)
tilefigs
