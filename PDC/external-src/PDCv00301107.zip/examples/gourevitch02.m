% Example Model 2: Linear bivariate model with bidirectional influence 
%                          with common source
%
%               Gour�vitch, Bouquin-Jeannes, Faucon
% Linear and nonlinear casuality between signals: methods, examples and
% neurophysiological applications. Biol Cybern 95:349-369, 2006.

clear all; clc
N=20000;
disp('======================================================================');
disp('          Linear Bivariate model with Bidirectional Influence ')
disp('                         with Common Source')
disp('             Gour�vitch et al. Biol Cybern 95:349-369, 2006')
disp('         x1-->x2    x2-->x1   x1--x2 (Instantaneous causality)');
disp('======================================================================');

randn('state', sum(100*clock))
wi=randn(3,N);
x1=zeros(1,N);
x2=zeros(1,N);
for t=1:3,
   x1(t)=wi(1,t);
   x2(t)=wi(2,t);
end;
for t=4:N,
   x1(t) =  0.95*sqrt(2)*x1(t-1) - 0.9025*x1(t-2) ... 
                                     - 0.9*x2(t-1) + 0.5*wi(1,t) + 0.5*wi(3,t);
   x2(t) = -1.05*x2(t-1) - 0.85*x2(t-2) ...
                                     - 0.8*x1(t-1) + 0.5*wi(2,t) + 0.5*wi(3,t);
end;

nDiscard = 1000; % number of points discarded at beginning of simulation
nPoints  = 5000; % number of analyzed samples points

y=[x1' x2'];     % data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure; chLabels={'X1';'X2'}; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Gourevitch et al. Biol Cybern Model 2:' ...
                ' Linear bivariate model with common source.'],'t');
set(hT,'FontSize',14); % Title font size

disp('==> Note significant Instantaneous Causality in between this pair of ')
disp('    time series. The common influencing source is 0.5*wi(3,t) ')
disp('    in the model. The p-value (pValue) should be very small, p<0.001.')
disp('======================================================================');
disp('                    End of example gourevitch02.m');
disp('======================================================================');
