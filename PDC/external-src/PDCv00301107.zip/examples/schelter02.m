% Schelter, Winterhalder, Hellwig, Guschlbauer, L�cking, Timmer
% Direct or indirect? Graphical models for neural oscillators
% J Physiology - Paris 99:37-46, 2006.
% 
% Example VAR(5) 

clear all; clc
N=10000;
disp('======================================================================');
disp('                    NonLinear Bivariate Model II')
disp('         Schelter et al. J Physiology - Paris 99:37-46, 2006.')
disp('       x1-->x2  x1-->x4 x2-->x4 x4==>x5 x5-->x1  x5-->x2 x5-->x3 ');
disp('======================================================================');

randn('state', sum(100*clock))
ei=randn(5,N);
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x5=zeros(1,N);
% Variables initialization
for t=1:4,
   x1(t)=randn(1); x2(t)=randn(1); x3(t)=randn(1); x4(t)=randn(1);
   x5(t)=randn(1);
end;

for t=5:N,
   x1(t) = 0.4*x1(t-1) - 0.5*x1(t-2) + 0.4*x5(t-1) + ei(1,t);
   x2(t) = 0.4*x2(t-1) - 0.3*x1(t-4) + 0.4*x5(t-2) + ei(2,t);
   x3(t) = 0.5*x3(t-1) - 0.7*x3(t-2) - 0.3*x5(t-3) + ei(3,t);
   x4(t) = 0.8*x4(t-3) + 0.4*x1(t-2) + 0.3*x2(t-2) + ei(4,t);
   x5(t) = 0.7*x5(t-1) - 0.5*x5(t-2) - 0.4*x4(t-1) + ei(5,t);
end;

nDiscard=1000; % number of points discarded at beginning of series
nPoints=2000;   % number of analyzed samples points
aSignif = 0.05;

y=[x1' x2' x3' x4' x5']; % data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max);
[ax,hT]=suplabel(['Schelter et al. (2006) linear model: ' int2str(nPoints) ...
                  ' data points PDCn analysis.'],'t');
set(hT,'FontSize',14); % Title font size

disp('')
disp('==> Note that for linear model the mean amplitude of PDC estimates is')
disp('    roughly proportional to  relative coefficient values of ')
disp('    the autoregressive model.')
pause(10); maximize
disp('======================================================================');
disp('                    End of example schelter02.m');
disp('======================================================================');
