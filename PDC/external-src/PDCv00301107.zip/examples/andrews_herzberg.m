clear all; close all; clc
% Data File: skin.dat
% This data is from Andrews and Herzberg.
% The aetiology of melanoma is complex and may include the influences 
% of trauma, heredity and hormonal activity. In particular, exposure 
% to solar radiation may be involved in the pathogenesis of melanoma. 
% Melanoma is more common in fair-skinned individuals and most frequent 
% in skin sites exposed to the sun. In white populations melanoma is 
% more common in areas closer to the equator where the intensity of 
% solar radiation is higher. Data from various parts of the world suggest 
% that the incidence of melanoma is increasing. The data below, giving 
% age-adjusted melanoma incidence, are from the Connecticut Tumor Registry 
% from 1936-1972. Connecticut has the longest record of state 
% population-based cancer statistics in the United States of America. 
% The data also includes the sunspot relative number. Houghton, Munster 
% and Viola (1978) have shown that the age-adjusted incidence rate for 
% malignant melanoma in the state of Connecticut has risen since 1935 and 
% that superimposed on the rise are 3-5 year periods in which the rise 
% in the rate of incidence is excessive. These periods have a cycle of 
% 8-11 years and follow times of maximum sunspot activity. The relationship 
% between solar cycles and melanoma supports the hypothesis that melanoma 
% is related to sun exposure and provides evidence that solar radiation 
% may trigger the development of clinically apparent melanoma. The columns 
% are the year, male incidence, total incidence, and sunspot relative 
% index. The incidence are rates per 100,000.
% 
% Below is the contents of the file skin.dat:
% Year % 1936-1972
% ANNUAL MALE MELANOMA INCIDENCE(AGE-ADJUSTED PER 10**5) CONNECTICUT
% ANNUAL TOTAL MELANOMA INCIDENCE(AGE-ADJUSTED PER 10**5) CONNECTICUT
% ANNUAL SUNSPOT RELATIVE NUMBER 

%============= Causality Analysis using PDC ==============================
% In this example, ANNUAL SUNSPOT RELATIVE NUMBER and TOTAL MELANOMA 
% INCIDENCE(AGE-ADJUSTED PER 10**5) in the state of CONNECTICUT will be 
% considered

disp('======================================================================');
disp('     Andrews and Herzberg''s Sunspot and Melanoma 1936-1972 Data');
disp('                 Sunspot --> ^Melanoma or other way?');
disp('======================================================================');

u=sunmeladat([4 3]); % Selecting columns 4 and 3 of Andrews and Herzberg data.
year=sunmeladat(1);  % Year variable
figure; subplot(311); plot(year,u(:,1),'*:'); title('sunspot')
        grid
        subplot(312); plot(year,u(:,2),'.:'); xlabel(''); title('melanoma')
        grid
        
        subplot(313); plot(year,detrend(u(:,2)),'.:'); xlabel('year'); 
        title('detrended melanoma series')
        grid
        hold on
pause(5)

chLabels={'Sunspot';'Melanoma'};
%fighandle = newfig(1,'Sunspot and melanoma (1936-1972) example',1,1.5)
%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; 
%flgPrinting - Matrix Layout plotting flag
%flgPrinting=[(1)PDC    (2)Patnaik_Thresh (3)SignificantPDC 
%             (4)PDCinf (5)PDCsup         (6)Coh 
%             (7)PowerSpectrum(1: linear; 2: log)];
w_max=fs/2;
figure;; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max);
[ax,h3]=suplabel('Sunspot & Melanoma 1936-1972','t');
set(h3,'FontSize',14)

disp('======================================================================');
disp('           Press any key or wait for 10 sec to continue ...');
disp('======================================================================');
pause(5);
disp('                 Analysis of C-F transformed data')
disp('                 ================================');

% Cornish-Fisher Transformation
df=1;
figure; subplot(411); plot(year,u(:,1),'*:');  title('sunspot')
        grid
        subplot(412); plot(year,detrend(u(:,2)),'.:'); xlabel(''); 
        title('detrended melanoma series')
        grid

        u=cornish_fisher(u,df);
        subplot(413); plot(year,u(:,1),'.:'); xlabel(''); title('C-F Sunspot')
        grid
        subplot(414); plot(year,detrend(u(:,2)),'.:'); xlabel('year');
        title('C-F melanoma')
        grid
        hold on

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
%                               Same as above
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
figure; %Optional channel labels;
[hxlabel hylabel] = pdc_xplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max);
[ax,h3]=suplabel('Sunspot & Melanoma 1936-1972 with Cornish-Fisher transformation','t');
set(h3,'FontSize',14)

disp('==> Note that AIC estimate of Cornish-Fisher transformed data is smaller')
disp('    than for detrended original time series.')
disp('==> Also note higher and sharper peak of squared-PDC at period of about ')
disp('    11 years for C-F transformed data.')
pause(10)
tilefig

disp('======================================================================');
disp('                      End of Sunspot and Melanoma example');
disp('======================================================================');
