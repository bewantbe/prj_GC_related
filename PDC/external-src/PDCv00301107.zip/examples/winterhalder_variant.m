% Winterhalder et al.Comparison of linear signal processing techniques to
% infer directed interactions in multivariate neural systems. 
% Signal Processing 85:2137�2160, 2006.
%
% Example: Seven random independent variables 

clear all; clc

disp('======================================================================');
disp('        Variant of Random Independent Process with 7 variables')
disp('       Winterhalder et al. Signal Processing. 85:2137�60, 2006')
disp(' [sigma1=500|sigma2=1|sigma3=500|sigma4=1|sigma5=1|sigma6=1|sigma7=1]');
disp('======================================================================');

randn('state', sum(100*clock))
ei=randn(10,20000);

sigma1=500; sigma2=1; sigma3=500; sigma4=1; sigma5=1; sigma6=1; sigma7=1;

x1=sigma1*ei(1,:); x2=sigma2*ei(4,:); x3=sigma3*ei(6,:); x4=sigma4*ei(7,:);
x5=sigma5*ei(5,:); x6=sigma6*ei(2,:); x7=sigma7*ei(8,:);

y=[x1' x2' x3' x4' x5' x6' x7'];
nDiscard=1000; % number of points discarded at beginning of series
nPoints=5000;   % number of analyzed samples points
aSignif = 0.05;
u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Signwificance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                              flgPrinting,fs,w_max);
[ax,h3]=suplabel(['Independent Gaussian noises: \sigma_1=\sigma_3=500;' ...
                  ' \sigma_2 = \sigma_4 = \sigma_5 = 1'],'t');
set(h3,'FontSize',14)

disp('======================================================================');
disp('==> As forty-two combinations of PDC are tested, chance is that you')
disp('    will see significant PDC (red lines) in some plottings. This') 
disp('    probability depends also on significance level you choose for PDC') 
disp('    testing.')
disp('==> The same observation applies for "instantaneous Granger causality"' )
disp('    outcome, in which case 21 pairs of variables are considered since') 
disp('    IGC is a symmetric relation.')
pause(10);
maximize;
disp('======================================================================');
disp('                  End of winterhalder_variant.m');
disp('======================================================================');
