% Winterhalder et al.Comparison of linear signal processing techniques to
% infer directed interactions in multivariate neural systems. 
% Signal Processing 85:2137�2160, 2006.
%
% Example random independent variables

clear all; clc

disp('======================================================================');
disp('         Random Independent Variables with Unbalanced Variance')
disp('        Winterhalder et al. Signal Processing 85:2137�60, 2006')
disp('                sigma1 = 500; sigma2 = 1; sigma3 = 500;');
disp('======================================================================');

randn('state', sum(100*clock))
% White noise model
ei=randn(6,20000);
sigma1 = 500; sigma2 = 1; sigma3 = 500;
x1=sigma1*ei(1,:); x2=sigma2*ei(4,:); x3=sigma3*ei(6,:);

y=[x1' x2' x3']; % data must be organized column-wise
nDiscard=1000; % number of points discarded at beginning of series
nPoints=5000;   % number of analyzed samples points
aSignif = 0.05;
u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max);
[ax,h3]=suplabel(['Independent Gaussian noises:' ...
                         ' \sigma_1 = \sigma_3 = 500; \sigma_2 = 1.'],'t');
set(h3,'FontSize',14)

disp('======================================================================');
disp('                    End of winterhalder02.m');
disp('======================================================================');
