%Sunspot and melanoma data 1936 - 1972
%     sunspot --> melanoma 
sunmeladat

%==========================================================================
% Mario Ch�vez, Jacques Martinerie, Michel Le Van Quyen
% "Statistical assessment of nonlinear causality: application to epileptic
% EEG signals". J Neurosci Methods 2003
%==========================================================================
%
% Example nonlinear bivariate independent model Eq. (16)
chavez16

% Example: linear bivariate model
% (Diks and DeGoede, 2001).
chavez18

% Example Eq-(19): nonlinear bivariate model
%                      x1-->x2
chavez19

% Example (20): simple model bivariate conditional heteroskedasticity
% This is similar to the following example
% Gour�vitch, Bouquin-Jeannes, Faucon. Linear and nonlinear casuality 
% between signals: methods, examples and neurophysiological applications. 
% Biol Cybern 2006
chavez20

%==========================================================================
% Gour�vitch, Bouquin-Jeannes, Faucon
% Linear and nonlinear casuality between signals: methods, examples and
% neurophysiological applications. Biol Cybern 95:349-369, 2006.
%==========================================================================

% Example Model 2: Linear bivariate model with bidirectional influence 
% with common source
gourevitch02

% Example Model 5: nonlinear bivariate model
%                      x1-->x2
gourevitch05

% Example Model 6: Second nonlinear bivariate model 
%   x1(t)=wi(1,t); x2(t)=y(t)*x1(t-1)+wi(2,t);
%                      x1-->x2
gourevitch06

% Example Model 7: nonlinear trivariate model
%             x1-->x2; x1-->x3; x2-->x3
gourevitch07

%==========================================================================
% Schelter, Winterhalder, Eichler, Peifer,Hellwig, Guschlbauer, L�cking,
% Dahlhaus, Timmer. Testing for directed influences among neural 
% signals using partial directed coherence. Journal of Neuroscience Methods
% 152:210-218, 2005.
%==========================================================================
% Example VAR(5) 
schelter01

%==========================================================================
% J Physiology - Paris 99:37-46, 2006.
% Direct or indirect? Graphical models for neural oscillators
% Bj�rn Schelter, Matthias Winterhalder, Bernhard Hellwig, 
% Brigitte Guschlbauer, Carl Hermann L�cking, Jens Timmer
%==========================================================================
% 
% Example VAR(5) 
schelter02

%==========================================================================
% Winterhalder et al.Comparison of linear signal processing techniques to
% infer directed interactions in multivariate neural systems. 
% Signal Processing 85:2137�2160, 2006.
%==========================================================================
% Example of random independent variables (3 variables)
winterhalder02

%==========================================================================
%        Variant of Random Independent Process with 7 variables')
%  sigma1=500; sigma2=1; sigma3=500; sigma4=1; sigma5=1; sigma6=1; sigma7=1;
%
% Example: Seven random independent variables 

winterhalder_variant
