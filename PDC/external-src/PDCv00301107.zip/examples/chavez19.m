% Example Eq-(19): Nonlinear Bivariate model p.119.
%
%   ( Ch�vez, Martinerie, Van Quyen. Statistical assessment 
%     of nonlinear causality: Application to epileptic EEG signals. 
%     J Neurosci Methods. 124:113-128, 2003. )

clear all; clc
N=20000;
disp('======================================================================');
disp('               Equation (19): Nonlinear Bivariate Model.')
disp('            Chavez et al. J. Neurosci. Methods (2003)')
disp('                         x1-->x2');
disp('======================================================================');

randn('state', sum(100*clock))
wi=randn(2,N);
x1=zeros(1,N);
x2=zeros(1,N);
tini=3;
for t=1:tini,
   x1(t)=wi(1,t);
   x2(t)=wi(2,t);
end;

for t=(tini+1):N,
   x1(t)=-0.7*x1(t-1)+wi(1,t);
   x2(t)=0.1+0.4*x2(t-2)+(2.4-0.9*x1(t-3))/(1+exp(-4*x1(t-3)))+wi(2,t);   
end;
yy=[x1' x2']; % data must be organized column-wise


nDiscard=1000; % number of points discarded at beginning of simulated series
nSamples=5000;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nSamples,:);
%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
disp('                   =========================');
disp('                   Analysis of original data');
disp('                   =========================');
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure; chLabels={'X1';'X2'}; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel('Chavez et al Eq-19: Analysis of original data.','t');
set(hT,'FontSize',14); % Title font size

disp('======================================================================');
disp('=========== Press any key or wait 10 sec to continue ...==============');
disp('======================================================================');
pause(10);
%==========================================================================
%                        Cornish-Fisher Transformation
%==========================================================================
disp('                 ================================');
disp('                 Analysis of C-F transformed data')
disp('                 ================================');
df=1; % degree of freedom for Cornish-Fisher Transf.
u=cornish_fisher(u,df);

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                               anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                              flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Chavez et al Eq-19: ' ...
                                 'Cornish-Fisher transformation effect.'],'t');
set(hT,'FontSize',14); % Title font size

disp('======================================================================');
disp('                      End of Chavez20 example');
disp('======================================================================');
