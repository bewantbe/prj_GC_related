% 
% Example nonlinear bivariate independent model Eq. (16) p.118.
%
%   ( Ch�vez, Martinerie, Van Quyen. Statistical assessment 
%     of nonlinear causality: Application to epileptic EEG signals. 
%     J Neurosci Methods. 124:113-128, 2003. )


clear all; clc
N=20000;
disp('======================================================================');
disp('                Nonlinear Bivariate Independent Model');
disp('        Equation 16: Chavez et al. J. Neurosci. Methods (2003)')
disp('======================================================================');

%randn('state', sum(100*clock)); %randn initial 'seed' randomization
randn('state', 2007);
wi=randn(2,N);
y=zeros(1,N);
x=zeros(1,N);
for t=1:2,
   y(t)=wi(1,t);
   x(t)=wi(2,t);
end;

sigma=wi(1,:);
v=wi(2,:);

for t=3:N,
   y(t)=-0.7 + 0.9/(1+y(t-1)^2+y(t-2)^2) + 0.1*sigma(t);
   x(t)=0.7*x(t-1)+v(t);
end;

u=[y' x']; % data must be organized column-wise

nDiscard=1000; % number of points discarded at beginning of simulated series
nPoints=5000;  % number of analyzed samples points
u=u(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     Simultaneous 6-channel PDC Analysis
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure; chLabels={'Y';'X'}; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Chavez & cols. (JNM 2003): Nonlinear bivariate' ...
                  'independent model'],'t');
set(hT,'FontSize',14); % Title font size

disp('======================================================================');
disp('                      End of example chavez16.m                       ');
disp('======================================================================');
