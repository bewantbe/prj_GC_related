% Gour�vitch, Bouquin-Jeannes, Faucon
% Linear and nonlinear casuality between signals: methods, examples and
% neurophysiological applications
% Biol Cybern 95:349-369, 2006.
% Example Model 5: nonlinear bivariate model
clear all; clc
N=10000;
randn('state', sum(100*clock))
wi=randn(2,N);

disp('======================================================================');
disp('                     NonLinear Bivariate Model ')
disp('             Gour�vitch et al. Biol Cybern 95:349-369, 2006')
disp('                               x1-->x2');
disp('======================================================================');
x1=zeros(1,N);
x2=zeros(1,N);
for t=1:3,
   x1(t)=wi(1,t);
   x2(t)=wi(2,t);
end;
for t=4:N,
   x1(t)=0.7*x1(t-1)+wi(1,t);
   x2(t)=0.1 + 0.4*x2(t-2)+(2.4 - 0.9*x1(t-3))/(1+exp(-4*x1(t-3)))+wi(2,t);
end;

y=[x1' x2'];     % data must be organized column-wise
nDiscard = 1000; % number of points discarded at beginning of simulation
nPoints  = 5000; % number of analyzed samples points

u=y(nDiscard+1:nDiscard+nPoints,:);
%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure; chLabels={'X1';'X2'}; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);

[ax,hT]=suplabel(['Gourevitch et al. Biol Cybern Model 5:' ...
                  ' nonlinear bivariate model'],'t');
set(hT,'FontSize',14);

disp('======================================================================');
disp('           Press any key or wait 10 sec to continue ...');
disp('======================================================================');
pause(10);
disp('                 Analysis of C-F transformed data')
disp('                 ================================');
df=1;
u=cornish_fisher(u,df);
%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
figure; 
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Gourevitch et al. Biol Cybern Model 5: ' ...
                  'Effect of Cornish-Fisher transformation'],'t');
set(hT,'FontSize',14);

disp('======================================================================');
disp('                      End of example gourevitch05.m');
disp('======================================================================');
