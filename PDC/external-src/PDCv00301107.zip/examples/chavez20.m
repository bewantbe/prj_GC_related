% Equation 20 (p.119): "Simple Model Bivariate Conditional Heteroskedasticity"
%                                          
%   ( Ch�vez, Martinerie, Van Quyen. Statistical assessment 
%     of nonlinear causality: Application to epileptic EEG signals. 
%     J Neurosci Methods. 124:113-128, 2003. )
%
% This example is similar to Example Model 6, Second nonlinear bivariate
% model, by  Gour�vitch et al. (Biol Cybern 2006)
% 

clear all; clc
N=20000;
disp('======================================================================');
disp('            Chavez et al. J. Neurosci. Methods (2003)')
disp('         Equation 20: Bivariate conditional heteroskedasticity')
disp('                             Y-->X');
disp('======================================================================');

randn('state', sum(100*clock))
x=zeros(1,N);
wi=randn(2,N+1);
sigma=wi(1,1:N+1);
y=sigma(1,2:N+1); 
for t=1:N,
   x(t)=sigma(t)*wi(2,t);
end;
yy=[x' y'];

nDiscard=1000; % number of points discarded at beginning of simulated series
nSamples=5000;  % number of analyzed samples points
u=yy(nDiscard+1:nDiscard+nSamples,:);
%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.01; % Significance level for PDC testing, usually 1% or 5%.

%==========================================================================
%                            PDCn calculation
%==========================================================================
disp('                ------------------------------');
disp('                Analysis of untransformed data');
disp('                ==============================');
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure; chLabels={'X';'Y'}; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                              flgPrinting,fs,w_max,chLabels);
suplabel('Chavez et al., Eq-20: Analysis of original data.','t')

disp('----------------------------------------------------------------------');
disp('------------- Press any key or wait for 10 sec to continue -----------');
disp('----------------------------------------------------------------------');
pause(10);
%==========================================================================
%                        Cornish-Fisher Transformation
%==========================================================================
disp('                 --------------------------------');
disp('                 Analysis of C-F transformed data')
disp('                 ================================');
df=1; % degree of freedom for Cornish-Fisher Transf.
u=cornish_fisher(u,df);

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                               anapdcn(u,fs,maxIP,criterion,alg,aSignif);
%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                              flgPrinting,fs,w_max,chLabels);
suplabel('Chavez et al., Eq-20: Cornish-Fisher transformation.','t')

disp('----------------------------------------------------------------------');
disp('                      End of example chavez20.m                       ');
disp('----------------------------------------------------------------------');
