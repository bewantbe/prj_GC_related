% Schelter, Winterhalder, Eichler, Peifer,Hellwig, Guschlbauer, L�cking,
% Dahlhaus, Timmer. Testing for directed influences among neural 
% signals using partial directed coherence. Journal of Neuroscience Methods
% 152:210-218, 2005.
% 
% Example VAR(5) 
%

clear all; clc
N=10000;
disp('======================================================================');
disp('                    NonLinear Bivariate Model II')
disp('       Schelter et al. J Neurosci Methods. 152:210-218, 2005.')
disp('       x2==>x1  x3-->x2 x3==>x4 x3-->x5 x4==x2 x5-->x3  x5==x4');
disp('======================================================================');

randn('state', sum(100*clock))
% Variables initialization
ei=randn(5,N);
x1=zeros(1,N);
x2=zeros(1,N);
x3=zeros(1,N);
x4=zeros(1,N);
x5=zeros(1,N);
for t=1:4,
   x1(t)=randn(1); x2(t)=randn(1); x3(t)=randn(1); x4(t)=randn(1);
   x5(t)=randn(1);
end;

for t=5:10000,
   x1(t) = 0.6*x1(t-1) + 0.65*x2(t-2) + ei(1,t);
   x2(t) = 0.5*x2(t-1) - 0.3*x2(t-2) - 0.3*x3(t-4) + 0.6*x4(t-1) + ei(2,t);
   x3(t) = 0.8*x3(t-1) - 0.7*x3(t-2) - 0.1*x5(t-3) + ei(3,t);
   x4(t) = 0.5*x4(t-1) + 0.9*x3(t-2) + 0.4*x5(t-2) + ei(4,t);
   x5(t) = 0.7*x5(t-1) - 0.5*x5(t-2) - 0.2*x3(t-1) + ei(5,t);
end;

nDiscard=100;  % Number of points discarded at beginning of simulation
nPoints=2000;  % Number of analyzed samples points
aSignif=0.05;  % Significance level for PDC testing
y=[x1' x2' x3' x4' x5']; % Data must be organized column-wise
u=y(nDiscard+1:nDiscard+nPoints,:); % Segment selection
%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1;           % 1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max);
[ax,hT]=suplabel(['Schelter & al.(JNM 2005): Linear pentavariate model, ' ...
    int2str(nPoints) ' data points analysis.'],'t');
set(hT,'FontSize',14); % Title font size
disp('')
disp('==> Note that for linear model roughly the amplitude of PDC estimates is')
disp('    proportional to the autoregressive model coefficients.')

disp('======================================================================');
disp('                    End of schelter01.m');
disp('======================================================================');
