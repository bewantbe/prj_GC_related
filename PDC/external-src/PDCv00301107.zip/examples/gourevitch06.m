% Biol Cybern 2006
% Linear and nonlinear casuality between signals: methods, examples and
% neurophysiological applications
% Gour�vitch, Bouquin-Jeannes, Faucon
% Example Model 6: Second nonlinear bivariate model 
clear all; clc

randn('state', sum(100*clock))
N=20000;
disp('======================================================================');
disp('                     NonLinear Bivariate Model II')
disp('             Gour�vitch et al. Biol Cybern 95:349-369, 2006')
disp('                               x1-->x2');
disp('======================================================================');

%Model simulation
wi=randn(2,N);
y=randn(1,N);
x1=zeros(1,N);
x2=zeros(1,N);
x1(1)=wi(1,1); 
x1(2)=wi(1,2); 
x2(2)=y(2)*x1(2-1)+wi(2,2); 
for t=3:N,
   x1(t)=wi(1,t);
   x2(t)=y(t)*x1(t-1)+wi(2,t);
end;

y=[x1' x2'];           % data must be organized column-wise

nDiscard = 1000; % number of points discarded at beginning of simulation
nPoints  = 5000; % number of analyzed samples points

u=y(nDiscard+1:nDiscard+nPoints,:);

%==========================================================================
%                     PDCn estimation and analysis parameters
%==========================================================================
fs=1; maxIP=30; criterion=1; % AIC - Akaike Information Criteria
alg=1; %1 = Nutall-Strand MVAR estimation algorithm
aSignif  = 0.05; % Significance level for PDC testing

%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %flgPrinting=[1 1 1 1 1 1 1];
w_max=fs/2;
figure; chLabels={'X1';'X2'}; %Optional channel labels;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Gourevitch et al. Biol Cybern Model 6:' ...
                  'nonlinear bivariate model'],'t');
set(hT,'FontSize',14);
disp('==> Note that PDC can not uncover nonlinear influence of x1 on x2 .')
disp('    A na�ve/intuitive explanation is that x1 influence on x2 is ')
disp('    "modulated" by a stochastic factor, y, which can be either ')
disp('    positive or negative in random way.')
disp('==> In this particular example, the Cornish-Fisher transformation is')
disp('    effective to uncover the directed dependence of x1 on x2 primarily')
disp('    because it takes the absolute values of both series.')
disp('==> Be aware that C-F transformation shifts frequency scale of ')
disp('    time series (aliasing), hence be careful on how you interpret PDC')
disp('    results.')
disp('======================================================================');
disp('           Press any key or wait for 10 sec to continue ...');
disp('======================================================================');
pause(10);
disp('                 Analysis of C-F transformed data')
disp('                 ================================');

df=1;
u=cornish_fisher(u,df);
%==========================================================================
%                            PDCn calculation
%==========================================================================
[SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
                                     anapdcn(u,fs,maxIP,criterion,alg,aSignif);

%==========================================================================
%                        PDCn Matrix Layout Plotting
%==========================================================================
figure;
[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);
[ax,hT]=suplabel(['Gourevitch et al. Model 6 ' ...
                                    'with Cornish-Fisher transformation'],'t');
set(hT,'FontSize',14);

disp('======================================================================');
disp('==> Now you might be able to see a significant PDC(2 <-- 1) increase ')
disp('    after Cornish-Fisher transformation over all frequency range.')
disp('==> This example shows that the C-F transformation is an interesting ')
disp('    exploratory procedure to eventually uncover some type of nonlinear ')
disp('    interdependence in the data set.')
disp('======================================================================');
disp('                      End of example gourevitch06.m');
disp('======================================================================');
