%
% Path installation for PDC Package 
%       Lab 11/2007
%
%  original_path - variable contains original MATLAB path
%
a=cd;
v=matlabpath;
original_path=v;
b=[v pathsep a '\artfit']
matlabpath(b);
b=[b pathsep a  '\doc']
matlabpath(b);
b=[b pathsep a  '\examples']
matlabpath(b);
b=[b pathsep a  '\supporting']
matlabpath(b);
b=[b pathsep a  '\pdc']
matlabpath(b);


