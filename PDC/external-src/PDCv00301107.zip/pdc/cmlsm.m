function [npf,na,nef]=cmlsm(u,IP);
% MVAR least squares estimator
%
%function [npf,na,nef]=cmlsm(u,IP);
%
%input:   u   - vector of rows
%         IP  - order
% output: npf - error covariance
%         na  - model
%         nef - residue

[m n]=size(u);
[b,SU,e]=mlsmx(u,IP);
na=reshape(b,m,m,IP);
npf=SU*n; % see normalization
nef=e;


%
% 01/30/1998 - L.A.B. 11/4/2000 (LAB revisto
%
function [b,SU,u]=mlsmx(Y,p);
[K,T]=size(Y);
Z=zmatrm(Y,p);
Gamma=Z*Z';
U1=inv(Gamma)*Z;
Gamma=Gamma/T;
SU=(Y*Y'-Y*Z'*U1*Y');SU=SU/(T-K*p-1);
b=kron(U1,eye(K))*reshape(Y,K*T,1);
u=reshape(reshape(Y,K*T,1)-kron(Z',eye(K))*b,K,T); 