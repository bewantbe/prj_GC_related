% Computation of Z - data structure (no estimation of the mean)
%
% function Z=zmatr(Y,p);
%
% input:  Y - data in row vectors 
%         p - model covariance order
%
% output: Z
%
% 01/30/1998 - L.A.B.
%
function Z=zmatr(Y,p);
[K T] = size(Y);
y1 = [zeros(K*p,1);reshape(flipud(Y),K*T,1)];
Z =  zeros(K*p,T);
for i=0:T-1
   Z(:,i+1)=flipud(y1(1+K*i:K*i+K*p));
end
%Z=[ones(1,T);Z];

