%
% Arfit capsule
%
function [pf,A,ef]=arfitcaps(u,IP)
v=u';
[w, Au, C, sbc, fpe, th]=arfit(v,IP,IP);
pf=C;
[siglev,res]=arres(w,Au,v);
ef=res';
siglev;
A=zeros(length(w),length(w),IP);
for i=1:IP
   A(:,:,i)=Au(:,(i-1)*length(w)+1:i*length(w));
   wu=ceil(length(ef)*rand(size(w)));
   if length(ef)<length(v)
      ef=[ef ef(:,wu(1))];
   else
      ef=ef(:,1:length(v));
   end
end
