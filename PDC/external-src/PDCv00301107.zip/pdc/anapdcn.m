function [SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
             anapdcn(u,fs,maxIP,criterion,alg,aSignif)
%Template function for express single segment PDCn computation with
%plotting.
%
%SS,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,Tr,pValue,IP] = ...
%                                   anapdcn(u,fs,maxIP,criterion,alg,aSignif)
%
% input: u     - data in columns
%        fs    - Sampling frequency
%        maxIP - externally defined maximum IP
%        alg   - for algorithm (1: Nutall-Strand),(2: mlsm) ,
%                              (3: Vieira Morf),  (4: QR artfit)
%        criterion - for AR order choice - 1: AIC; 2: Hanna-Quinn; 3: Schwartz;
%                                          4: FPE, 5: fixed order in MaxIP
%                                          6: xdelay,  7,8: Broersen
%                                          9: derivative (future) (envelope)
%                                         10: estimate up to maxIP
%                                           Negative - keep criterion changes
%        aSignif  -  PDC test significance level
%
% output: SS - Power spectrum
%         Lpdc - normalized/generalized PDC
%         Lpatnaik - significance threshold by Patnaik approximation
%         LTra - 
%         Lpdcvinf,Lpdcvsup - superior and inferior confidence interval
%                             calculated by Patnaik approximation 
%         Tr - Instantaneous Granger causality test result matrix
%         pValue - Instantaneous Granger causality test p-value matrix
%         IP - selected AR order

if nargin < 6, error('anapdcn.m needs at least 9 input arguments.'); end;
if nargin < 10, chLabels=[]; end;
if nargin < 9, flgTra=0; end;
if nargin < 8, flgThresh=0; end;
if nargin < 7, flgPdc=0; end;

nFreqs=64; % number of points on frequency scale
option=2; disp('PDCn calculation.')
metric=2; disp('Asymptotic statistics.')

flgDetrend=1;   if flgDetrend, disp('Time series were detrended.'); end;
flgNormalize=0;   if flgNormalize, disp('Time series were normalized.'); end;
flgLabels = ~isempty(chLabels); 

if aSignif > 0.20
   disp('* WARNING: significance level value is greater than 20%. *')
   pause(5);
end;
aValue=1-aSignif;
igt_signif=aValue; % Instantaneous Granger causality test significance

[nSegLength,nChannels]=size(u);
if flgLabels, 
   if nChannels ~= max(size(chLabels))
      error('Numbers labels and channels do not match.')
   end;
end;

%================
if flgDetrend,
   for i=1:nChannels,
      u(:,i)=detrend(u(:,i));
   end;
end;

if flgNormalize,
   for i=1:nChannels,
      u(:,i)=u(:,i)/std(u(:,i));
   end;
end;

%==========================================================================
% MAR model inference
%==========================================================================
switch alg
   case 1
      disp('MVAR estimation using Nutall-Strand algorithm.')
   case 2
      disp('MVAR estimation using least-squares estimator.')
   case 3
      disp('MVAR estimation using Vieira-Morf algorithm.')
   case 4
      disp('MVAR estimation using QR-Arfit algorithm.')
end;

[IP,pf,A,pb,B,ef,eb,vaic,Vaicv] = mvar(u',maxIP,alg,criterion);

disp(['Number of channels = ' int2str(nChannels) ' with ' ...
  int2str(nSegLength) ' data points; MAR model order = ' int2str(IP) '.']);
%==========================================================================
% Normalized PDC calculation and its asymptotic statistics
%==========================================================================
Z=zmatrm(u',IP); gamma=Z*Z';
[SS Lpdc LTra Lpdcvinf Lpdcvsup Lpatnaik] = pdcn(A,pf,nFreqs,nSegLength,...
                                               gamma,option,metric,aValue);

%==========================================================================
% Instantaneous Granger causality test routine
%==========================================================================
[Tr,Va,v,th,pValue]=granmaty(pf,nSegLength,igt_signif);

   
%==========================================================================
% Testing for adequacy of MAR model fitting through Portmanteau test
%==========================================================================
[Pass,Portmanteau,st,ths]=mvarresidue(ef,nSegLength,IP,0.95,20);

if Portmanteau
   disp(['Good MAR model fitting! Residues white noise hypothesis ' ...
        'NOT rejected.'])
else
   disp(['(**) Poor MAR model fitting:'])
   disp('                   Residues white noise hypothesis was rejected.')
end;
Pass
st
%==========================================================================
format compact
disp('Instantaneous Granger causality:')
disp('Results matrix')
Tr
disp('Instantaneous Granger causality test p-values')
pValue
nPairsIGC = (sum(sum(Tr)))/2;
if nPairsIGC == 0,
   disp('Instantaneous Granger causality NOT detected.')
elseif nPairsIGC == 1,
   disp(['There is a pair of channels with significant instantaneous ' ...
                                                'Granger causality.'])
else   
   disp(['There are ' int2str(nPairsIGC) ...
                                   ' pairs of channels with significant'])
   disp('Instantaneous Causality.')
end;   
