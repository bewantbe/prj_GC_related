% Vech or vec is matrix column stacking operator function
%
%function y=vech(Y);
% 
% input:  Y - matrix
% output: y - Stacked column vector
%
% % 01/30/1998 - L.A.B.

function y=vech(Y);
y=[ ];
[m n]=size(Y);
for i=1:m
   y=[y ;Y(i:n,i)];
end
