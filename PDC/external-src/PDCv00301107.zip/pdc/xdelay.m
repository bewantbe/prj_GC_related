function y=xdelay(x,MaxIP,display);
% Xdelay criterion for AR order estimation
%
%function y=xdelay(x,MaxIP,display);
if nargin<3
    display=0;
end
[m n]=size(x);
k=0;
y=zeros(n*(n-1),1);
lxo=length(x)-MaxIP; 
m=lxo-MaxIP+1
for i=1:n
    for j=1:n
        k=k+1;
        if i>j
           v=xcorr(x(MaxIP:lxo,i),x(MaxIP:lxo,j),'coef');
           if ~display
               figure
               plot(v)
               pause
               close
            end
            if isempty((find(abs(v)>2/sqrt(m))))
                q=m;
            else
               [p q]=max(abs(v));
               [pu qu]=sort(abs(v));
               q=qu(length(qu));
               q
               length(lxo-MaxIP)
            end

            y(k)=abs(q-m);
        end
    end
end
y=sort(y);
u=find(y==0);
y1=y;
y1=y1(u(length(u))+1:length(y));

y=y1;
if display
    figure
    hist(y)
    pause
    close
end
y=median(y)
if isempty(y)
    y=MaxIP
end
if y>MaxIP
    y=MaxIP;
end
