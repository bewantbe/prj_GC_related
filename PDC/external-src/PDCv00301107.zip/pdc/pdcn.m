function [SS,Lpdc,LTra,Lpdcvinf,Lpdcvsup,Lpatnaik] = ...
                         pdcn(A,pf,nFreqs,nSegLength,gamma,option,metric,aValue)
%Compute Partial^Directed^Coherence from MAR estimate
%
%[SS Lpdc LTra Lpdcvinf Lpdcvsup Lpatnaik] = ...
%                        pdcn(A,pf,nFreqs,nSegLength,gamma,option,metric,aValue)
% input: A          - MAR model matrix
%        pf         - covariance matrix
%        nSegLength - signal sample points
%        nFreqs     - 
%        gamma      -
%        option     -
%        metric     -
%        aValue     -
%
% output: SS       - Power spectrum
%         Lpdc     - normalized PDC
%         LTra     - PDC above threshold value
%         Lpdcvinf - pdc confidence interval
%         Lpdcvsup - superior and inferior
%         Lpatnaik - threshold calculated by Patnaik approximation

[SS,Lpdc,Lpatnaik,fvar] = prpardd(A,pf,nFreqs,nSegLength,gamma,option, ...
   metric,aValue);

% Significant PDC values on frequency scale
Ltemp = (abs(Lpdc).^2-Lpatnaik.^2>0).*Lpdc+(abs(Lpdc).^2-Lpatnaik.^2<=0)*(-1);
Ltemp(ind2sub(size(Ltemp),find(Ltemp==-1))) = NaN; 
LTra = Ltemp;

Ltemp(ind2sub(size(Ltemp),find(Ltemp~=-1))) = 1;

% Upper and lower variances are only defined for significant PDC range.
% Variance upper
Lpdcvsup = sqrt(abs(Lpdc).^2 + fvar).*Ltemp;
% Variance lower
Lpdcvinf = sqrt(abs(Lpdc).^2 - fvar).*Ltemp;
