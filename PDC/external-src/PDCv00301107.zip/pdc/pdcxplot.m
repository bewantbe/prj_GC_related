% PDC plot in matrix layout with power spectra in the main diagonal.
%
%[hxlabel,hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf, ...
%                                        Lpdcvsup,flgPrinting,fs,w_max,chLabels)
% 
% input: SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,- data structure
%        flgPrinting = []
%        fs - sampling frequency
%        w_max - frequency scale upper-limit
%        chLabels - channel identification labels
%
% output: graphics
%         hxlabel, hylabel = graphic label's handles 

function [hxlabel,hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf, ...
                                       Lpdcvsup,flgPrinting,fs,w_max,chLabels)
                                   
[N,q,nFreqs]=size(Lpdc); % N = Number of channels/time series; N==q
                         % nFreqs = number of points on frequency scale
nodesett=1:N;
if nargin <  8, flgPrinting = [1 1 1 0 0 0 1]; end;
if nargin <= 8,  fs=1; end
if nargin < 10, w_max = fs/2; end

w = 0:fs/(2*nFreqs):w_max-fs/(2*nFreqs);
nPlotPoints = length(w);
w_min = w(1);

if nargin < 11 | isempty(chLabels), 
   chLabels=[]; 
elseif max(size(chLabels)) < N, 
   error('NOT ENOUGH CHANNEL LABELS.');
end;

hxlabel=0; % x-axis labels' handles
hylabel=0; % y-axis labels' handles

for j=1:N
   s=nodesett(j);
   for i=1:N,
      r=nodesett(i);
      if j~=i | (j==i & flgPrinting(7) ~= 0)
         h=subplot2(N,N,(i-1)*N+j);
         set(h,'FontSize',[10],'FontWeight','bold')
      end;

%==========================================================================
%====================== Power spectrum plotting ===========================
%==========================================================================
      if j == i, %Power spectrum
         y=abs(reshape(SS(r,s,1:nPlotPoints), nPlotPoints,1,1,1,1));
            
         if flgPrinting(7)==1,
            plot(h,w,y,'LineWidth',2.5)
            set(h,'XLim', [w_min w_max], 'XTick',[0 .1 .2 .3 .4 .5], ...
               'YLim', [0 1.05*max(y)], ...
               'FontSize',[10],'FontWeight','bold');
         elseif flgPrinting(7)==2,
            plot(h,w,log(y),'LineWidth',2.5)
            if j==2,
               hh=ylabel('log Spectra [a.u.]');
               set(hh,'FontWeight','bold');
               disp('Power spectra in log-scale plotting [arbitrary unit].')
            end;
            set(h,'XLim', [w_min w_max],'XTick',[0 .1 .2 .3 .4 .5], ...
               'YTickLabel',['  ']);
         end;
         if j == 1,
            hylabel(i)=labelity(i,chLabels);
         end;
         if j == N,
            hxlabel(j)=labelitx(j,chLabels);
         end;
         if flgPrinting(7)==0
%             set(h,'XTickLabel',[' ';' ';' ';' ';' ';' '], ...
%                'YTickLabel',[''])
         else
         set(h, 'Color', 0.8*[1 1 1]) % Background color
            if j == N,
               hxlabel(j)=labelitx(j,chLabels);
               set(h,'XTickLabel',[' ';' ';' ';' ';' ';' '])
            else
               set(h,'XTickLabel',[' ';' ';' ';' ';' ';' '])
            end;
         end;
%==========================================================================
%======================PDC and coherence plotting =========================
%==========================================================================
      else % PDC and coherence
         if flgPrinting(1),
            atrib='g-'; % PDCn in green lines
            if flgPrinting(6),
               plot(w,abs(reshape(Coh(r,s,1:nPlotPoints),nPlotPoints, ...
                  1,1,1,1)).^2,'k-','LineWidth',3);
               hold on
               plot(h,w,abs(reshape(Lpdc(r,s,1:nPlotPoints),nPlotPoints, ...
                  1,1,1,1)).^2,atrib,'LineWidth',3);
            else
               plot(h,w,abs(reshape(Lpdc(r,s,1:nPlotPoints),nPlotPoints, ...
                  1,1,1,1)).^2,atrib,'LineWidth',3);
            end;

            if i==N,
               if j==1,
                  hylabel(i)=labelity(i,chLabels);
                  hxlabel(j)=labelitx(j,chLabels);
                  set(h,'XLim', [w_min w_max], 'YLim',[0 1.01], ...
                     'XTick',[0 .1 .2 .3 .4 .5], ...
                     'XTickLabel',[' 0';'  ';'  ';'  ';'  ';'.5'], ...
                     'FontSize',[10],'FontWeight','bold', ...
                     'YTick',[0 .5 1],'YTickLabel',[' 0';'.5';' 1']);
               else
                  hxlabel(j)=labelitx(j,chLabels);

                  set(h,'XLim', [w_min w_max], 'YLim',[0 1.01], ...
                     'XTick',[0 .1 .2 .3 .4 .5], ...
                     'XTickLabel',[' ';' ';' ';' ';' ';' '], ...
                     'YTick',[0 .5 1],'YTickLabel',['  ';'  ';'  ']);
               end;
            elseif j == 1,
            hylabel(i)=labelity(i,chLabels);

               set(h,'XLim', [w_min w_max],'YLim',[0 1.01], ...
                  'XTick',[0 .1 .2 .3 .4 .5], ...
                  'XTickLabel',[' ';' ';' ';' ';' ';' '], ...
                  'YTick',[0 .5 1], 'YTickLabel',['  '; '  '; '  '], ...
                  'FontSize',[10],'FontWeight','bold');
               if i == N,
                  set(h,'FontSize',[10],'FontWeight','bold', ...
                     'YTick',[0 .5 1], 'YTickLabel',[' 0'; '.5'; ' 1']);
               end;
            else
               set(h,'XLim', [w_min w_max], 'YLim',[0 1.01], ...
                  'XTick',[0 .1 .2 .3 .4 .5], ...
                  'XTickLabel',[' ';' ';' ';' ';' ';' '], ...
                  'FontSize',[10],'FontWeight','bold', ...
                  'YTick',[0 .5 1], 'YTickLabel',['  '; '  '; '  ']);
            end;
            hold on
         end;
         if flgPrinting(2)==1,
            atrib='k--'; % Patnaik significance level in black line
            plot(h,w,abs(reshape(Lpatnaik(r,s,1:nPlotPoints), ...
               nPlotPoints,1,1,1,1)).^2, atrib,'LineWidth',2);
         end;
         if flgPrinting(3)==1,
            atrib='r-'; % Significant PDCn in red line
            plot(h,w,abs(reshape(LTra(r,s,1:nPlotPoints), ...
               nPlotPoints,1,1,1,1)).^2,atrib,'LineWidth',3);
         end;
         if flgPrinting(4)
            %Lpdcvinf
            disp('PDC confidence interval not implemented yet.')
         end;
         if flgPrinting(5)
            %Lpdcvsup
            disp('PDC confidence interval not implemented yet.')
         end;
         if flgPrinting(6)
            %Coh
            %disp('Coherence plotting not implemented yet.')
         end;
      end; % PDC and coherence
   end;
end;

[ax,h1]=suplabel('Source');
set(h1, 'FontSize',[12], 'FontWeight', 'bold')
[ax,h1]=suplabel('Target','y');
set(h1, 'FontSize',[12], 'FontWeight', 'bold')

%==========================================================================
function [hxlabel]=labelitx(j,chLabels) % Labels x-axis plottings
if isempty(chLabels)
            hxlabel=xlabel(['\bf{\it{j}} \rm{\bf{ = ' int2str(j) '}}']);
            set(hxlabel,'FontSize',[10],'FontWeight','bold', ...
                           'FontName','Times')
else
            hxlabel=xlabel(chLabels{j});
            set(hxlabel,'FontSize',[10],'FontWeight','bold')
end;

%==========================================================================
function [hylabel]=labelity(i,chLabels) % Labels y-axis plottings
if isempty(chLabels)
            hylabel=ylabel(['\bf{\it{i}} \rm{\bf{ = ' int2str(i) '}}'],...
                              'Rotation',90);
            set(hylabel,'FontSize',[10],'FontWeight','bold', ...
               'FontName','Times')
else
            hylabel=ylabel(chLabels{i},'Rotation',90);
            set(hylabel,'FontSize',[10],'FontWeight','bold')
end;
