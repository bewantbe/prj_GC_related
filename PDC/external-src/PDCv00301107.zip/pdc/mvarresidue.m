function [Pass,Portmanteau,st,ths]=mvar_residue(ef,ns,p,aValue,h)
% Residues test for whiteness
% 
% input: ef = matrix of column vectors - residues
%        ns - number of points estimated
%        p - model order      
%        aValue - confidence
%        h - lag - maximu lag
%
% output: Pass - # of computed correlation coefficients
%         st - Portmanteau statistic
%         ths - threshold value
%         Portmanteau test:  0 reject, 
%                            1 not rejected (white hypothesis)
%
%         reference: Luktpohl(1993) Chap.                                                                                               4
%         LAB 11/Apr/2000
%         KS  28/Apr/2007
if ~exist('h','var'), h=10; end
ef=ef';
[t,Portmanteau,st,ths,compr]=crosstest(ef,h,ns,aValue,p);
Pass=t/compr;
