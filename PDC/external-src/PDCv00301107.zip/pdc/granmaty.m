function [Tr,Va,v,th,pValue]=granmaty(pf,N,significance);
% Test Granger causality structure
%
%[Tr,Va,v,th,pValue]=granmaty(SU,N,significance);
% Program to test granger causality structure
%
% input: N (number of points)
%        pf - covariance of modelling errors
%        significance - test significance level
%
% output: Tr -test result matrix (i,j) entry=1 j->i causality cannot
%             be rejected
%         Va - test value matrix
%         v  - degrees of freedom
%         th - threshold value
%         pValue - test p-value
%
% % 01/30/1998 - L.A.B.
%
% disp('Instantaneous Granger causality test: ');
% significance
[n m]=size(pf);
Va=zeros(n,m);
Tr=zeros(n,m);
CO=zeros(n,m);
pValue=zeros(n,m);
for i=1:n
   for j=1:n
      if i>j
         CO(i,j)=1;
         [Tr(i,j),Va(i,j),v,th,pValue(i,j)]=instata(CO,pf,N,significance);
         Tr(j,i)=Tr(i,j);
         Va(j,i)=Va(i,j);
         CO(i,j)=0;
         pValue(j,i)=pValue(i,j);
      end
   end
end

%==========================================================================
function [y,value,v,th,pValue]=instata(CO,pf,N,significance);
% Test for instataneous causality
% input: CO - matrix describing the structure for testing - 1 position to test.
%        pf - residual covariance
%        N - number of poinst
%
% output: y - test result - 0 instantaneous causality rejected - 1 not rejected
%         value - test value
%         v - degrees of freedom # constraints.
%         th -threschold
si=vech(pf);
CO=tril(CO);
[m n]=size(CO);
lb=length(si);
Ct=vech(CO);
Ct1=zeros(size(Ct'));
Ctf=[ ];
l=sum(Ct');
for i=1:length(Ct)
   if Ct(i)==1
      Ct1(i)=1;
      Ctf=[Ctf; Ct1];
      Ct1=zeros(size(Ct'));
   end
end
C=Ctf;
ln=length(pf);
D=pinv(dmatrix(ln));
value=N*(C*si)'*inv(2*C*D*kron(pf,pf)*D'*C')*C*si;
v=2; % Chi-square distribution degree of freedom.
th=chi2inv(significance,v);
y=value>=th;
pValue=1-chi2cdf(value,v); % p-value of instantaneous Granger causality test

%==========================================================================
%  vec=D vech
%
%  01/30/1998 - L.A.B.
%
function D=dmatrix(m);
D=zeros(m*m,m*(m+1)/2);
u=[ ];
v=[];
for j=1:m
   for i=1:m
      u=[u ;[i j]];
      if j<=i
         v=[v ;[i j]];
      end
   end
end
w=fliplr(v);
for i=1:m*m
   for j=1:m*(m+1)/2
      if sum(u(i,:)==v(j,:))==2
         D(i,j)=1;
      end
   end
   for j=1:m*(m+1)/2
      if sum(u(i,:)==w(j,:))==2
         D(i,j)=1;
      end
   end
end