function [SS,L,th,fvar]=prpardd(A,pf,nFreqs,np,G,option,metric,avalue)
%Compute Partial^Directed^Coherence from series j to i.
%
%function [SS,L]=prpardd(A,pf,nFreqs,option,metric)
%
% input: A - power spectral density estimate of the i-th time-series
%        pf - covariance matrix
%        nFreqs - number of point in [0,fs/2]
%        np - number of sample points
%        G
%        option - 0 - L=[classic coherence], 1 (L=dircor), 2  L=pardir,
%                 3   L=transfer.   4- partial coherence
%        metric   1 - Euclidean,
%                 2 - diagonal,
%                 3 - statistical,
%                 4 - unnormalized,
%                 5 - weighted by Si(f) receiver
%                 6 - weighted by Sj(f) sender
%                 7 - joint weighted
%        avalue = .95 default for distribution
%        Note: Pdcn - metric=2 - option=2
%
% output: SS
%         SS - power spectrum for each sequence.
%         According to option
%         L = G -(dircor) or
%         L= PG (pardir
%         L= H - transfer function gain - modified 11:55 AM 3/22/2000 (LAB)
%         th - Threshold value with (1-avalue) significance level.
%         fvar - confidence interval variance for significant PDC|DTF|DC|Coh
%                

mflag=0;
if nargin==5,
   option=2; metric=1;avalue=.95;
end

[nChannels,n0,nIP]=size(A);
SS=zeros(nChannels,nChannels,nFreqs);
L=zeros(nChannels,nChannels,nFreqs);
th=zeros(nChannels,nChannels,nFreqs);
fvar=zeros(nChannels,nChannels,nFreqs);

optionr=0;
if (metric==5)|(metric==6)|(metric==7),
   mflag=metric;
   metric=1;
end

if option==4, %Partial coherence
   metric=3;
   optionr=1;
   option=2;
end

switch metric
   case 1 % Euclidean
      pu=eye(nChannels);
   case 2 % Diagonal
      pu=diag(diag(pf));
   case 3 % Statistical
      pu=pf; % needs revision
   case 4 % Unnormalized
      pu=eye(nChannels);
end;

if option==2, pu=pinv(pu); end % For PDC

Omega=kron(inv(G),sqrt(pu)*pf*sqrt(pu)*np);
Omega_a=kron([1 1]'*[1 1],Omega);

for iFreqs=0:nFreqs-1
   f=iFreqs/(2*nFreqs);
   AL=eye(nChannels,nChannels);
   for j=1:nIP
      AL=AL-A(:,:,j)*exp(-sqrt(-1)*2*j*pi*f);
   end
   AT=pinv(AL);

   % Matrix C
   Cmat=[ ];
   Smat=[ ];

   for r=1:nIP
      divect=2*pi*f*r*ones(1,nChannels^2);
      cvector=cos(divect);
      svector=-sin(divect);
      Cmat=[Cmat diag(cvector)];
      Smat=[Smat diag(svector)];
   end
   Zmat=zeros(size(Cmat));
   Cjoint=[Cmat Zmat;Zmat -Smat];
   Ct=Cjoint*Omega_a*Cjoint';
   if option==1
      TH=-kron(AT',AT);
      THr=real(TH);
      THi=imag(TH);
      TH=[THr -THi;THi THr];
      Ct=TH'*Ct*TH;
   end

   SU=AT*pf*AT';
   SS(:,:,iFreqs+1)=SU;

   if option==0  % Classical Coherence computation
      %
      %--vector version--
      %
      % SV=inv(sqrt(diag(diag(SU))));
      % L(:,:,iFreqs+1)=SV*SU*SV;
      %
      for iu=1:nChannels
         for ju=1:nChannels
            L(iu,ju,iFreqs+1)=SU(iu,ju)./sqrt(SU(iu,iu).*SU(ju,ju));
         end
      end
   else % option~=0
      for iu=1:nChannels
         for ju=1:nChannels
            % eigenvalue computation
            Co=[Ct((ju-1)*nChannels+iu,(ju-1)*nChannels+iu) ...
               Ct((ju-1)*nChannels+iu,(nChannels+ju-1)*nChannels+iu);
               Ct((nChannels+ju-1)*nChannels+iu,(ju-1)*nChannels+iu)  ...
               Ct((nChannels+ju-1)*nChannels+iu,(nChannels+ju-1)*nChannels+iu)];
            v=eig(Co);

            Pat=gaminv(avalue,.5*sum(v)^2/(2*v'*v),2);

            if option==1 % DTF/DC
               if metric==1
                  SP=AT*AT';
                  L(iu,ju,iFreqs+1)=AT(iu,ju)*sqrt(pu(ju,ju))/sqrt(SP(iu,iu)); % Coherences
                  nL(iu,ju,iFreqs+1)=AT(iu,ju)*sqrt(pu(ju,ju));
                  dL(iu,ju,iFreqs+1)=SP(iu,iu);
                  th(iu,ju,iFreqs+1)=Pat/np*abs(dL(iu,ju,iFreqs+1))^2;

                  dLu=abs(dL(iu,ju,iFreqs+1));
                  nLu=abs(nL(iu,ju,iFreqs+1))^2;
                  th(iu,ju,iFreqs+1)=sqrt(Pat/((sum(v)/(2*v'*v))*(np*abs(dL(iu,ju,iFreqs+1)))));
                  %
                  I_ij=zeros(nChannels^2,nChannels^2);
                  I_j=I_ij;
                  I_ij((ju-1)*nChannels+iu,(ju-1)*nChannels+iu)=1;

                  I_t=find(rem(1:nChannels^2,nChannels)+iu-1==1);
                  I_j(I_t,I_t)=1;

                  I_j=diag(diag(I_j));
                  Icj=[I_j zeros(size(I_j)); zeros(size(I_j)) I_j];
                  Ic=[I_ij zeros(size(I_ij)); zeros(size(I_ij)) I_ij];
                  %
                  rr=reshape(AT,nChannels^2,1);
                  a=[real(rr); imag(rr)];

                  G=2*( Ic*a/dLu - Icj*a*nLu/(dLu^2));

                  fvar(iu,ju,iFreqs+1)=G'*Ct*G;

               elseif metric==2
                  SP=AT*pu*AT';
                  L(iu,ju,iFreqs+1)=AT(iu,ju)*sqrt(pu(ju,ju))/sqrt(SP(iu,iu));
                  nL(iu,ju,iFreqs+1)=AT(iu,ju)*sqrt(pu(ju,ju));
                  dL(iu,ju,iFreqs+1)=SP(iu,iu);

                  dLu=abs(dL(iu,ju,iFreqs+1));
                  nLu=abs(nL(iu,ju,iFreqs+1))^2;
                  th(iu,ju,iFreqs+1)=sqrt(Pat/((sum(v)/(2*v'*v))* ...
                                               (np*abs(dL(iu,ju,iFreqs+1)))));
                  %
                  I_ij=zeros(nChannels^2,nChannels^2);
                  I_j=I_ij;
                  I_ij((ju-1)*nChannels+iu,(ju-1)*nChannels+iu)=1;
                  %1
                  I_t=find(rem(1:nChannels^2,nChannels)+iu-1==1);
                  I_j(I_t,I_t)=1;
                  % 1 review
                  I_j=diag(diag(I_j));
                  Icj=[I_j zeros(size(I_j)); zeros(size(I_j)) I_j];
                  Ic=[I_ij zeros(size(I_ij)); zeros(size(I_ij)) I_ij];
                  %
                  rr=reshape(pu*AT,nChannels^2,1);
                  a=[real(rr); imag(rr)];
                  G=2*((Ic*a)/(dLu)-(Icj*a*nLu)/(dLu)^2);
                  fvar(iu,ju,iFreqs+1)=G'*Ct*G;
                  %========================================================
               elseif metric==3
                  % review
                  L(iu,ju,iFreqs+1)=AT(iu,ju)*sqrt(pf(ju,ju))/sqrt(SU(iu,iu)); 
                  nL(iu,ju,iFreqs+1)=AT(iu,ju)*sqrt(pu(ju,ju));
                  dL(iu,ju,iFreqs+1)=sqrt(SU(iu,iu));
                  th(iu,ju,iFreqs+1)=Pat/((sum(v)^2/(2*v'*v))* ...
                                              (np*abs(dL(iu,ju,iFreqs+1))^2));
                  %iu,ju
                  %pause ==================================================
               else metric==4
                  L(iu,ju,iFreqs+1)=AT(iu,ju);
               end
            end
            % ==========PDC/PDCn===========================================
            if option==2
               if metric==4
                  L(iu,ju,iFreqs+1)=AL(iu,ju);
               elseif metric==2 % PDCn

                  L(iu,ju,iFreqs+1)=sqrt(pu(iu,iu))*AL(iu,ju)/ ...
                                                  sqrt(AL(:,ju)'*pu*AL(:,ju));
                  nL(iu,ju,iFreqs+1)=sqrt(pu(iu,iu))*AL(iu,ju);
                  dL(iu,ju,iFreqs+1)=AL(:,ju)'*pu*AL(:,ju);
                  %
                  th(iu,ju,iFreqs+1)=Pat/pu(iu,iu)*np*abs(dL(iu,ju,iFreqs+1));
                  %
                  dLu=abs(dL(iu,ju,iFreqs+1));
                  nLu=abs(nL(iu,ju,iFreqs+1))^2;
                  th(iu,ju,iFreqs+1)=sqrt(Pat/((sum(v)/(2*v'*v))* ...
                                               (np*abs(dL(iu,ju,iFreqs+1)))));
                  %
                  I_ij=zeros(nChannels^2,nChannels^2);
                  I_j=I_ij;
                  I_ij((ju-1)*nChannels+iu,(ju-1)*nChannels+iu)=1;
                  I_j((ju-1)*nChannels+1:ju*nChannels,(ju-1)* ...
                                                  nChannels+1:ju*nChannels)=1;
                  I_j=diag(diag(I_j));
                  Icj=[I_j zeros(size(I_j)); zeros(size(I_j)) I_j];
                  Ic=[I_ij zeros(size(I_ij)); zeros(size(I_ij)) I_ij];
                  %
                  rr=reshape(sqrt(pu)*AL,nChannels^2,1);
                  a=[real(rr); imag(rr)];
                  G=2*( Ic*a/dLu - Icj*a*nLu/(dLu^2));

                  %% Confidence interval computation for generalized PDC
                  %% by DY Takahashi 21July2007
                  weight=diag(kron(ones(2*nChannels,1),diag(sqrt(pu))));
                  fvar(iu,ju,iFreqs+1)=G'*weight'*Ct*weight*G;
                  %norminv(1-aValue/2,0,1)/sqrt(np);

               elseif metric==1 % PDC original
                  L(iu,ju,iFreqs+1)=AL(iu,ju)/sqrt(AL(:,ju)'*pu*AL(:,ju));
                  nL(iu,ju,iFreqs+1)=AL(iu,ju);
                  dL(iu,ju,iFreqs+1)=AL(:,ju)'*pu*AL(:,ju);
                  %
                  dLu=abs(dL(iu,ju,iFreqs+1));
                  nLu=abs(nL(iu,ju,iFreqs+1))^2;
                  th(iu,ju,iFreqs+1)=sqrt(Pat/((sum(v)/(2*v'*v))* ...
                                               (np*abs(dL(iu,ju,iFreqs+1)))));
                  %
                  I_ij=zeros(nChannels^2,nChannels^2);
                  I_j=I_ij;
                  I_ij((ju-1)*nChannels+iu,(ju-1)*nChannels+iu)=1;
                  I_j((ju-1)*nChannels+1:ju*nChannels,(ju-1)* ...
                                                  nChannels+1:ju*nChannels)=1;
                  I_j=diag(diag(I_j));
                  Icj=[I_j zeros(size(I_j)); zeros(size(I_j)) I_j];
                  Ic=[I_ij zeros(size(I_ij)); zeros(size(I_ij)) I_ij];
                  %
                  rr=reshape(AL,nChannels^2,1);
                  a=[real(rr); imag(rr)];
                  G=2*((Ic*a)/(dLu)-(Icj*a*nLu)/(dLu)^2);
                  fvar(iu,ju,iFreqs+1)=G'*Ct*G;
                  %*norminv(1-avalue/2,0,1)/sqrt(np);
               end
            end % Partial directed Coherences
            %======= Transfer function =====================================
            if option==3
               L(iu,ju,iFreqs+1)=-AL(iu,ju)/AL(iu,iu); % Baccala et 1998
            end
            %======= Partial coherence =====================================
            if optionr==1 % Partial coherence
               L(iu,ju,iFreqs+1)=(AL(:,iu)'*pu*AL(:,ju))/ ...
                       sqrt((AL(:,iu)'*pu*AL(:,iu))*(AL(:,ju)'*pu*AL(:,ju)));
            end
         end
      end
   end
end

if mflag>0,
   for iu=1:nChannels
      for ju=1:nChannels
         if mflag==5
            L(iu,ju,:)=L(iu,ju,:).*SS(ju,ju,:)./max(SS(ju,ju,:));
         elseif mflag==6
            L(iu,ju,:)=L(iu,ju,:).*SS(iu,iu,:)./max(SS(iu,iu,:));
         elseif mflag==7
            L(iu,ju,:)=L(iu,ju,:).*SS(iu,iu,:).*SS(ju,ju,:)/ ...
                                        (max(SS(ju,ju,:))*max(SS(iu,iu,:)));
         end
      end
   end
end

switch option
   case 0
      disp('option = 0: Classical Coherence')
   case 1
      disp('option = 1: DTF/DC')
   case 2
      if metric ==2
         disp('option = 2 metric = 2: Generalized Partial Directed Coherence')
      elseif metric == 1
         disp('option = 2 metric = 1: Partial Directed Coherence original')
      else
         disp('option = 2 metric <> 0 or 1: Unexpected')
      end;
   case 3
      disp('option = 3: Transfer function')
   case 4
      disp('option = 4: Partial Coherence')
   otherwise
      disp('option = 0: Partial Coherence')
end
