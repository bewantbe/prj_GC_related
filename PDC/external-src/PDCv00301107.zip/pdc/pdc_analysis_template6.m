%PDC analysis getting started template file
%
% Edit this file to analyze your data. You might want to choose analysis
% parameters followed by comment containing "<***>". Check bellow.
%
% Some important input and output parameters and variables:
% input
%        u     - data in columns
%        fs    - Sampling frequency
%        maxIP - externally defined maximum IP
%        alg   - for algorithm (1: Nutall-Strand),(2: mlsm) ,
%                              (3: Vieira Morf),  (4: QR artfit)
%        criterion - for AR order selection =>
%                                   1: AIC; 2: Hanna-Quinn; 3: Schwartz;
%                                   4: FPE, 5: fixed order in MaxIP
%                                   6: xdelay,  7,8: Broersen
%                                   9: derivative (future) (envelope)
%                                  10: estimate up to maxIP
%                                  Negative - keep criterion changes
%        aSignif  -  PDC test significance level
%
% output: SS - Power spectrum
%         Lpdc - normalized/generalized PDC
%         Lpatnaik - significance threshold by Patnaik approximation
%         Lpdcvinf,Lpdcvsup - superior and inferior confidence interval
%                             calculated by Patnaik approximation 
%         Tr - Instantaneous Granger causality test result matrix
%         pValue - Instantaneous Granger causality test p-value matrix
%         IP - AR order
% 

%===========================#
% Times series for analysis /
%===========================#
% u     - data in columns.
%         The variable u must contain the time series 
%         you want to analyze. The original  template file will analyze a 
%         5 variables Gaussian independent noises.
format compact

% Uncomment one of the lines bellow for: Example (1) 5 independent variables model
%                                        Example (2) Sunspot-melanoma time series
%u=randn(2000,5);    %<***> Example (1)
u=sunmeladat([4 3]); %<***> Example (2)

fs=1; %<***> Sampling frequency

[nSegLength,nChannels]=size(u);
if nSegLength < nChannels, error('Your data might be transposed.'); end;

%===========================#
%  Channel identification   /
%===========================#
chLabels=[];                    %<***> Example (1)
%chLabels={'Sunspot';'Melanoma'}; %<***> Example (2)

flgLabels = ~isempty(chLabels); 
if flgLabels, 
   if nChannels ~= max(size(chLabels))
      error('Numbers of labels and channels do not match.')
   end;
end;

%===========================#
%       Action flags        /
%===========================#
flgDetrend=1;   %<***> Usually it's advisable to detrend the time series.
if flgDetrend, disp('Time series were detrended.'); end;
flgNormalize=0; %<***> For PDCn estimation normalization has no effect.
if flgNormalize, disp('Time series were normalized.'); end;

%===========================#
%    Analysis parameters    /
%===========================#
nFreqs=64; %<***> number of points on frequency scale
option=2;  %<***> disp('PDCn calculation.') 
metric=2;  %<***> disp('Asymptotic statistics.')
maxIP = 30; % maxIP - externally defined maximum IP %<***>

%===========================#
%    MAR algorithm          /
%===========================#
% Choose one of algorithm for MAR estimation
% alg   - for algorithm  (1: Nutall-Strand),(2: mlsm) ,
%                        (3: Vieira Morf),  (4: QR artfit)

alg=1; %<***> Nuttall-Strand algorithm seems to be a good and robust method.

%============================#
%MAR order selection criteria/
%============================#
% criterion - for AR order choice 
%  1: AIC; 2: Hannan-Quinn; 3: Schwartz;
%  4: FPE, 5: fixed order in MaxIP
%  6: xdelay,  7,8: Broersen
%  9: derivative (future) (envelope)
%  10: estimate up to maxIP
%  Negative - keep criterion changes

criterion = 1; %<***> AIC, Akaike information criterion (Our prefered one)

%================
aSignif = 0.05;    %<***> Significance level for PDC/Coh/DTF/DC Analysis
aValue=1-aSignif;        
igt_signif=aValue; % Instantaneous Granger causality test significance. Edit 
                   % this line if you want to use different aValue from PDC
                   % testing.
aValuePortmanteau = 0.95; % Significance level of 5% is a good choice.
%================
if flgDetrend,
   for i=1:nChannels,
      u(:,i)=detrend(u(:,i));
   end;
end;

if flgNormalize,
   for i=1:nChannels,
      u(:,i)=u(:,i)/std(u(:,i));
   end;
end;

%===========================#
%  Plotting parameter       /
%===========================#
Coh=[];
flgPrinting=[1 1 1 0 0 0 1]; %<***> flgPrinting=[1 1 1 1 1 1 1];
%flgPrinting - Matrix Layout plotting flag
%              Fill zero if you don't want to plot, one otherwise.
%            = [(1)PDC        (2)Patnaik_Thresh (3)SignificantPDC 
%               (4)PDCinf     (5)PDCsup         (6)Coh 
%               (7)PowerSpectrum];
% flgPrinting(7) the seventh element value determine y-axis scale for the
%               power spectrum plotting on main diagonal, 1=Linear 2=Log 

w_max=fs/2; %<***> Usually half of sampling frequency = Nyquist frequency

%==========================================================================
%==========================================================================
%        ATTENTION: BELOW THIS LINE PROBABLY YOU MIGHT NOT WANT TO EDIT,
%            UNLESS YOU WANT TO CUSTOMIZE YOUR ANALYSIS ROUTINE.
%==========================================================================
%==========================================================================
switch alg
   case 1
      disp('MVAR estimation using Nutall-Strand algorithm.')
   case 2
      disp('MVAR estimation using least-squares estimator.')
   case 3
      disp('MVAR estimation using Vieira-Morf algorithm.')
   case 4
      disp('MVAR estimation using QR-Arfit algorithm.')
end;
%==========================================================================
%                         MAR model inference
%==========================================================================
[IP,pf,A,pb,B,ef,eb,vaic,Vaicv] = mvar(u',maxIP,alg,criterion);

disp(['Number of channels = ' int2str(nChannels) ' with ' ...
  int2str(nSegLength) ' data points; MAR model order = ' int2str(IP) '.']);
   
%==========================================================================
%      Normalized PDC calculation and asymptotic statistics (option=2)
%==========================================================================
Z=zmatrm(u',IP); gamma=Z*Z'; clear Z
[SS Lpdc LTra Lpdcvinf Lpdcvsup Lpatnaik] = pdcn(A,pf,nFreqs,nSegLength,...
                                               gamma,option,metric,aValue);

%==========================================================================
%      Coherence calculation and its asymptotic statistics (option=0)
%==========================================================================
if flgPrinting(6),
   option=0;
   [Dummy Coh LcohTra Lcohvinf Lcohvsup Lcohthres] = pdcn(A,pf,nFreqs, ...
      nSegLength,gamma,option,metric,aValue);
   clear Dummy; % Discarding. SS was already computed on previous pdcn call.
end;
%==========================================================================
%   Testing for adequacy of MAR model fitting through Portmanteau test
%==========================================================================
h=50; %Maximum lag for cross-correlation computation in the residue testing

[Pass,Portmanteau,st,ths]=mvarresidue(ef,nSegLength,IP,aValuePortmanteau,h);

if Portmanteau
   disp(['Good MAR model fitting! Residues white noise hypothesis ' ...
        'NOT rejected.'])
else
   disp(['(**) Poor MAR model fitting:'])
   disp('                   Residues white noise hypothesis was rejected.')
end;

Pass
st

%==========================================================================
%            Instantaneous Granger causality test routine
%==========================================================================
[Tr,Va,v,th,pValue]=granmaty(pf,nSegLength,igt_signif);

disp('Instantaneous Granger causality:')
disp('Results matrix')
Tr
disp('Instantaneous Granger causality test p-values')
pValue
nPairsIGC = (sum(sum(Tr)))/2;

if nPairsIGC == 0,
   disp('Instantaneous Granger causality was NOT detected.')
elseif nPairsIGC == 1,
   disp('A pair of channels shows significant instantaneous Granger causality.')
else   
   disp(['There are ' int2str(nPairsIGC) ' pairs of channels with significant'])
   disp('instantaneous Granger causality.')
end;   

%==========================================================================
%              Matrix Layout Plotting of the Analysis Results
%==========================================================================
figure;
% Uncomment the next 2 lines for Matlab 7
%[hxlabel hylabel] = pdcxplot(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
%                                               flgPrinting,fs,w_max,chLabels);

%And comment out the next 2 lines for Matlab 7 
[hxlabel hylabel] = pdcxplot6(SS,Coh,Lpdc,Lpatnaik,LTra,Lpdcvinf,Lpdcvsup,...
                                               flgPrinting,fs,w_max,chLabels);

% Program set up for Matlab 6.5

%<***> Example (1)
 [ax,h3]=suplabel(['Five independent Gaussian noises'],'t');

%<***> Example (2)
% [ax,h3]=suplabel(['Sunspot & Melanoma 1936-1972 with' ...
%                                        ' Cornish-Fisher transformation'],'t');

set(h3,'FontSize',14)


%======================= pdc_xplot ========================================
%Plot legend:  Blue lines on the main diagonal = Power spectra;
%              Black dashed lines = Patnaik threshold for PDCn;
%              Green lines = non significant PDCn;
%              Red lines = significant PDCn;
%              Black lines = coherence function.
%
% Notes:       a.The main diagonal of matrix layout contains power spectra.    
%              b.Coherences are symmetric, i.e.,  
%                      Coh_Sunspot,Melanoma(f) = Coh_Melanoma,Sunspot(f).
%              c.PDCn is asymmetric relation, and the PDCn graphics should
%              be read as if the flow of information is been from the 
%              x-axis variable toward y-axis variable.
%
%              For sunspot and melanoma example, one only sees significant
%              PDCn from Sunspot to Melanoma, which could eventually be
%              interpreted that "Sunspot", or the Sun's activity 
%              modulates the incidence of melanoma.
%======================= pdc_xplot ========================================

disp('==========PDC_ANALYSIS_TEMPLATE SUCCESSFULLY FINISHED ==============')
