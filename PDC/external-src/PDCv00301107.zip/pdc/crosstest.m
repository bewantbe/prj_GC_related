%Cross-correlation computation between data signal column vectors
%
%function [t,Portmanteau,s,ths,compr,X]=crosstest(u,h,ns,th,p);
%
% input: u = matrix of column vectors - residues
%        h - lag - maximu lag
%        ns - number of points estimated
%        th - confidence
%        p - model order
%
% output: t - correlation test - number of times the 2/sqrt(ns) threshold is exceeded
%         Portmanteau - test result - 0 - REJECT , 1 not rejected (white hypothesis)
%         s - portamanteau statistic
%         ths - threshold value
%         compr - # of computed correlation coefficients
%         X - cross correlation vector columns: order 11 12 ... 21 22 .. etc
%                   (i-1)*nseries+j
%         reference:Luktpohl(1993) Chap. 4
%         LAB 11/4/2000
%
function [t,Portmanteau,s,ths,compr,X]=crosstest(u,h,ns,th,p);
if nargin==4
   p=0;
end
[m n]=size(u);
C=zeros(n,n,h);
X=xcorr(u,h,'coeff');
for i=h+1:2*h+1
   C(:,:,i-h)=reshape(X(i,:),n,n);
end
%Teste simples
t=sum(sum(sum(abs(C(:,:,2:h+1))>2/sqrt(ns))));
% Portmanteau
s=0;
SO=pinv(C(:,:,1));
for i=2:h
   s=s+((ns-i)^(-1))*trace(C(:,:,i)'*SO*C(:,:,i)*SO);
end
s=ns^2*s;
ths=chi2inv(th,(h-p)*n^2);
Portmanteau=s<ths;
compr=n*n*h;
