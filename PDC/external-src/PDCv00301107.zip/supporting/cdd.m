function []=cdd();
% CDD - Change directory
 
[a b] = uigetfile('*.*', 'Escolha um arquivo para mudar de diretorio');

if length(b) < 4,
   eval(['cd ' b]);
else
   eval(['cd(''' b(1:(length(b)-1)) ''')' ]);
end;

cd

