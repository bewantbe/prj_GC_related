function y=cornish_fisher(x,df)
% Cornish-Fisher transformation

k=-1+2/9/df;
y=sqrt(9*df/2)*(((x.^2)/df).^(1/3)+k);
[m n]=size(x);
if m < n, error('Error: data structure probably transposed.'); end;
for i=1:n,
   y(:,i)=y(:,i)-mean(y(:,i));
end;
