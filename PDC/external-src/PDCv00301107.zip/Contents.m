% PDC distribuition contains basic routines for partial directed coherence
%     estimation with asymptotic statistics
%     http://www.lcs.poli.usp.br/~baccala/pdc/
%
% Copyright (C) 2007 by Luiz A. Baccal� <baccala@lcs.poli.usp.br>
%                       Koichi Sameshima <ksameshi@usp.br>
%                       Daniel Y. Takahashi <takahashiyd@gmail.com>
% WWW: http://biosig.sf.net/
% $Revision: 0.99 $ 
% $Id: Contents.m, v 0.99 2007/11/30 12:00:00 ksameshima $
%
% LICENSE:
%     This set of program is free software; you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation; either version 2 of the License, or
%     (at your option) any later version.
% 
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
% 
%     You should have received a copy of the GNU General Public License
%     along with this program; if not, write to the Free Software
%     Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
% 
% 
% Required Toolboxes: Control          (lyap function)
%                     Statistical      (chi2inv,chi2cdf,gaminv,functions)
%                     Signal Processing(xcorr function)
%
% 
% === INDEX  PDC === (according to directory)
% 
% THIS DIRECTORY
%
%  getting_started.txt
%  Contents.m            - This file 
%  path_install          - Path installation routine
%
% DOC: Documentation
% ---------------------------------------------
% 	PDC.pdf  
%       PDC.rtf 
% 
% PDC: [PDC routines] 
% ---------------------------------------------
% PDC
%
% Files
%   anapdcn               - Template function for express single segment PDCn computation with
%   arfitcaps             - Arfit capsule
%   cmlsm                 - MVAR least squares estimator
%   crosstest             - Cross-correlation computation between data signal column vectors
%   granmaty              - Test Granger causality structure
%   mcarns                - MVAR Nuttall-Strand algorithm
%   mcarvm                - MVAR estimation using Vieira Morf algorithm
%   mvar                  - Estimate MVAR
%   mvarresidue           - Residues test for whiteness
%   pdc_analysis_template - PDC analysis getting started template file (Matlab 7 only)
%   pdc_analysis_template6- PDC analysis getting started template file (Matlab 6.5 only)
%   pdcn                  - Compute Partial^Directed^Coherence from MAR estimate
%   pdcxplot              - PDC plot in matrix layout with power spectra in the main diagonal.
%                                  (Matlab 7.0)			
%   pdcxplot6             - PDC plot in matrix layout with power spectra in the main diagonal.
%                                  (Matlab 6.5)			
%   prpardd               - Compute Partial^Directed^Coherence from series j to i.
%   vech                  - Vech or vec is matrix column stacking operator function
%   xdelay                - Xdelay criterion for AR order estimation
%   zmatrm                - Computation of Z - data structure (no estimation of the mean)% 
%    
%
% EXAMPLES (For Matlab 7 only, For Matlab 6.5 edit/replace pdcxplot by pdcxplot6)
%
% Files
%   andrews_herzberg     - Data File: skin.dat
%   chavez16             - Example nonlinear bivariate independent model Eq. (16) p.118.
%   chavez18             - Equation (18): Linear Bivariate model (p.118)
%   chavez19             - Example Eq-(19): Nonlinear Bivariate model p.119.
%   chavez20             - Equation 20 (p.119): "Simple Model Bivariate Conditional Heteroskedasticity"
%   gourevitch02         - Example Model 2: Linear bivariate model with bidirectional influence 
%   gourevitch05         - Gour�vitch, Bouquin-Jeannes, Faucon
%   gourevitch06         - Biol Cybern 2006
%   gourevitch07         - Biol Cybern 2006
%   schelter01           - Schelter, Winterhalder, Eichler, Peifer,Hellwig, Guschlbauer, L�cking,
%   schelter02           - Schelter, Winterhalder, Hellwig, Guschlbauer, L�cking, Timmer
%   takahashi01          - Takahashi, Baccal�, Sameshima
%   test_all             - Sunspot and melanoma data 1936 - 1972
%   winterhalder02       - Winterhalder et al.Comparison of linear signal processing techniques to
%   winterhalder_variant - Winterhalder et al.Comparison of linear signal
%
%
% SUPPORTING
%
% Files
%   cdd            - Change directory
%   cornish_fisher - Cornish-Fisher transformation
%   maximize       - Size a window to fill the entire screen (Author: Bill Finger).
%   subplot2       - Modified SUBPLOT with decreased spacing for tiled positions (Author: Mathworks) 
%   sunmeladat     - Data File skin.dat from Andrews and Herzberg.
%   suplabel       - PLaces text as a title, xlabel, or ylabel on a group of subplots (Author: Ben Barrowes).
%   tilefigs       - <cpp> tile figure windows usage (Author: Charles Plum)
%
%
% ARTFIT (Authors: Tapio Schneider and Arnold Neumaier)
% http://www.mathworks.com/matlabcentral/files/174/content/index.html
%
% Files
%   acf       - Plot of sample autocorrelation function.
%   adjph     - Normalization of columns of a complex matrix.
%   arconf    - Confidence intervals for AR coefficients.
%   ardem     - Demonstrates modules of the ARfit package.
%   arfit     - Stepwise least squares estimation of multivariate AR model.
%   arfitcaps - Arfit capsule 
%   armode    - Eigendecomposition of AR model.
%   arord     - Evaluates criteria for selecting the order of an AR model.
%   arqr      - QR factorization for least squares estimation of AR model.
%   arres     - Test of residuals of fitted AR model.	
%   arsim     - Simulation of AR process.	
%   tquant    - Quantiles of Student's t distribution
